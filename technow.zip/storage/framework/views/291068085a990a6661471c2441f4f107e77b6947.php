<?php echo $__env->make('Web.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- /.mainHeader -->
<div class="btContentWrap btClear">
    <div class="btContentHolder">
        <div class="btContent">
            <div class="bt_bb_wrapper">
                <section id="bt_bb_section5fb501bab8240"
                    data-background_image_src="'http://avantage.bold-themes.com/marketing/wp-content/uploads/sites/4/2019/04/about-us-line-2.jpg'"
                    class="bt_bb_section bt_bb_top_spacing_extra_large bt_bb_bottom_spacing_large bt_bb_layout_boxed_1200 bt_bb_vertical_align_top btLazyLoadBackground bt_bb_background_image bt_bb_hidden_xs bt_bb_hidden_ms bt_bb_hidden_sm"
                    style="background-image:url(http_/avantage.bold-themes.com/marketing/wp-content/plugins/bold-page-builder/img/blank.html);background-position:center top;">
                    <div class="bt_bb_port">
                        <div class="bt_bb_cell">
                            <div class="bt_bb_cell_inner">
                                <div class="bt_bb_row_wrapper">
                                    <div class="bt_bb_row">
                                        <div class="bt_bb_column col-md-5 col-ms-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_animation_fade_in zoom_out animate bt_bb_padding_normal"
                                            data-width="5">
                                            <div class="bt_bb_column_content">
                                                <div
                                                    class="bt_bb_separator bt_bb_top_spacing_medium bt_bb_bottom_spacing_medium bt_bb_border_style_none">
                                                </div>
                                                <header
                                                    class="bt_bb_headline bt_bb_color_scheme_6 bt_bb_dash_top bt_bb_size_extralarge bt_bb_superheadline bt_bb_subheadline bt_bb_align_inherit">
                                                    <div class="bt_bb_headline_superheadline_outside"><span
                                                            class="bt_bb_headline_superheadline">GET IT RIGHT THE FIRST
                                                            TIME</span></div>
                                                    <h1><span class="bt_bb_headline_content"><span><u>Strive
                                                                    for</u><br />
                                                                <s><em>The Best</em></s></span></span>
                                                    </h1>
                                                    <div class="bt_bb_headline_subheadline">Uniquely matrix economically
                                                        sound value through cooperative technology. Competently parallel
                                                        task fully researched data and enterprise process improvements.
                                                    </div>
                                                </header>
                                                <div
                                                    class="bt_bb_separator bt_bb_bottom_spacing_medium bt_bb_border_style_none">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="bt_bb_column col-md-7 col-ms-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_padding_normal"
                                            data-width="7">
                                            <div class="bt_bb_column_content"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <section id="bt_bb_section5fb501bab8be3"
                    data-background_image_src="'http://avantage.bold-themes.com/marketing/wp-content/uploads/sites/4/2019/04/about-us-line-2.jpg'"
                    class="bt_bb_section bt_bb_top_spacing_extra_large bt_bb_bottom_spacing_large bt_bb_layout_boxed_1200 bt_bb_vertical_align_top btLazyLoadBackground bt_bb_background_image bt_bb_background_overlay_dark_solid bt_bb_hidden_md bt_bb_hidden_lg"
                    style="background-image:url(http_/avantage.bold-themes.com/marketing/wp-content/plugins/bold-page-builder/img/blank.html);background-position:center top;">
                    <div class="bt_bb_port">
                        <div class="bt_bb_cell">
                            <div class="bt_bb_cell_inner">
                                <div class="bt_bb_row_wrapper">
                                    <div class="bt_bb_row">
                                        <div class="bt_bb_column col-md-12 col-ms-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_animation_fade_in zoom_out animate bt_bb_padding_normal"
                                            data-width="12">
                                            <div class="bt_bb_column_content">
                                                <div
                                                    class="bt_bb_separator bt_bb_top_spacing_medium bt_bb_bottom_spacing_medium bt_bb_border_style_none">
                                                </div>
                                                <header
                                                    class="bt_bb_headline bt_bb_color_scheme_6 bt_bb_dash_top bt_bb_size_extralarge bt_bb_superheadline bt_bb_subheadline bt_bb_align_inherit">
                                                    <div class="bt_bb_headline_superheadline_outside"><span
                                                            class="bt_bb_headline_superheadline">GET IT RIGHT THE FIRST
                                                            TIME</span></div>
                                                    <h1><span class="bt_bb_headline_content"><span><b>Strive
                                                                    for</b><br />
                                                                <s><em>The Best</em></s></span></span>
                                                    </h1>
                                                    <div class="bt_bb_headline_subheadline">Uniquely matrix economically
                                                        sound value through cooperative technology. Competently parallel
                                                        task fully researched data and enterprise process improvements.
                                                    </div>
                                                </header>
                                                <div
                                                    class="bt_bb_separator bt_bb_bottom_spacing_medium bt_bb_border_style_none">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <section id="bt_bb_section5fb501babdfc0"
                    class="bt_bb_section bt_bb_top_spacing_large bt_bb_bottom_spacing_large bt_bb_layout_boxed_1200 bt_bb_vertical_align_top">
                    <div class="bt_bb_port">
                        <div class="bt_bb_cell">
                            <div class="bt_bb_cell_inner">
                                <div class="bt_bb_row_wrapper">
                                    <div class="bt_bb_row">
                                        <div class="bt_bb_column col-md-4 col-ms-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_animation_fade_in zoom_out animate bt_bb_padding_normal"
                                            data-width="4">
                                            <div class="bt_bb_column_content">
                                                <header
                                                    class="bt_bb_headline bt_bb_dash_top bt_bb_size_large bt_bb_superheadline bt_bb_align_inherit">
                                                    <div class="bt_bb_headline_superheadline_outside"><span
                                                            class="bt_bb_headline_superheadline">ABOUT US</span></div>
                                                    <h2><span class="bt_bb_headline_content"><span><u>Technow</u><br />
                                                                <b>our Mission</b></span></span>
                                                    </h2>
                                                </header>
                                                <div
                                                    class="bt_bb_separator bt_bb_bottom_spacing_normal bt_bb_border_style_none bt_bb_hidden_md bt_bb_hidden_lg">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="bt_bb_column col-md-2 col-sm-4 col-ms-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_padding_normal"
                                            data-width="2">
                                            <div class="bt_bb_column_content"></div>
                                        </div>
                                        <div class="bt_bb_column col-md-6 col-sm-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_animation_fade_in zoom_out animate bt_bb_padding_normal"
                                            data-width="6">
                                            <div class="bt_bb_column_content">
                                                <div class="bt_bb_text">
                                                    <blockquote>
                                                        <div>A mission becomes your constitution, the solid expression
                                                            of your vision and values. It becomes the criterion by which
                                                            you measure everything.</div>
                                                    </blockquote>
                                                    <div style="text-align: right;"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="bt_bb_row_wrapper">
                                    <div class="bt_bb_row">
                                        <div class="bt_bb_column col-md-12 col-ms-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_animation_fade_in animate bt_bb_padding_normal"
                                            data-width="12">
                                            <div class="bt_bb_column_content">
                                                <div class="bt_bb_separator bt_bb_top_spacing_normal bt_bb_bottom_spacing_medium bt_bb_border_style_solid"
                                                    style="; border-width: 2px"></div>
                                                <div class="bt_bb_row_inner">
                                                    <div class="bt_bb_column_inner col-md-4 col-ms-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_padding_normal"
                                                        data-width="4">
                                                        <div class="bt_bb_column_inner_content">
                                                            <div class="bt_bb_text">
                                                                <p>Completely synergize resource taxing relationships
                                                                    via premier niche markets. Professionally cultivate
                                                                    one-to-one customer service with robust ideas.
                                                                    Dynamically innovate resource-leveling customer
                                                                    service for state of the art customer service.</p>
                                                                <p>Objectively innovate empowered manufactured products
                                                                    whereas parallel platforms. Holisticly predominate
                                                                    extensible testing procedures for reliable supply
                                                                    chains. Dramatically engage top-line web services
                                                                    vis-a-vis cutting-edge deliverables.</p>
                                                                <p>Proactively envisioned multimedia based expertise and
                                                                    cross-media growth strategies. Seamlessly visualize
                                                                    quality intellectual capital without superior
                                                                    collaboration and idea-sharing. Holistically
                                                                    pontificate installed base portals after
                                                                    maintainable products.</p>
                                                                <p>Phosfluorescently engage worldwide methodologies with
                                                                    web-enabled technology. Interactively coordinate
                                                                    proactive e-commerce via process-centric
                                                                    &#8220;outside the box&#8221; thinking. Completely
                                                                    pursue scalable customer service through sustainable
                                                                    potentialities.</p>
                                                            </div>
                                                            <div
                                                                class="bt_bb_separator bt_bb_bottom_spacing_normal bt_bb_border_style_none bt_bb_hidden_md bt_bb_hidden_lg">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="bt_bb_column_inner col-md-4 col-ms-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_padding_normal"
                                                        data-width="4">
                                                        <div class="bt_bb_column_inner_content">
                                                            <div class="bt_bb_text">
                                                                <p>Phosfluorescently engage worldwide methodologies with
                                                                    web-enabled technology. Interactively coordinate
                                                                    proactive e-commerce via process-centric
                                                                    &#8220;outside the box&#8221; thinking. Completely
                                                                    pursue scalable customer service through sustainable
                                                                    potentialities.</p>
                                                                <p>Collaboratively administrate turnkey channels whereas
                                                                    virtual e-tailers. Objectively seize scalable
                                                                    metrics whereas proactive e-services. Seamlessly
                                                                    empower fully researched growth strategies and
                                                                    interoperable internal or &#8220;organic&#8221;
                                                                    sources.</p>
                                                                <p>Credibly innovate granular internal or
                                                                    &#8220;organic&#8221; sources whereas high standards
                                                                    in web-readiness. Energistically scale future-proof
                                                                    core competencies vis-a-vis impactful experiences.
                                                                    Dramatically synthesize integrated schemas with
                                                                    optimal networks.</p>
                                                                <p>Interactively procrastinate high-payoff content
                                                                    without backward-compatible data. Quickly cultivate
                                                                    optimal processes and tactical architectures.
                                                                    Completely iterate covalent strategic theme areas
                                                                    via accurate e-markets.</p>
                                                            </div>
                                                            <div
                                                                class="bt_bb_separator bt_bb_bottom_spacing_normal bt_bb_border_style_none bt_bb_hidden_md bt_bb_hidden_lg">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="bt_bb_column_inner col-md-4 col-ms-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_padding_normal"
                                                        data-width="4">
                                                        <div class="bt_bb_column_inner_content">
                                                            <div
                                                                class="bt_bb_progress_bar bt_bb_color_scheme_3 bt_bb_align_inherit bt_bb_size_normal bt_bb_style_line bt_bb_shape_rounded">
                                                                <div class="bt_bb_progress_bar_bg"></div>
                                                                <div class="bt_bb_progress_bar_inner animate"
                                                                    style="width:96%"><span
                                                                        class="bt_bb_progress_bar_text">Client
                                                                        Satisfaction</span></div>
                                                            </div>
                                                            <div
                                                                class="bt_bb_separator bt_bb_top_spacing_small bt_bb_border_style_none">
                                                            </div>
                                                            <div
                                                                class="bt_bb_progress_bar bt_bb_color_scheme_3 bt_bb_align_inherit bt_bb_size_normal bt_bb_style_line bt_bb_shape_rounded">
                                                                <div class="bt_bb_progress_bar_bg"></div>
                                                                <div class="bt_bb_progress_bar_inner animate"
                                                                    style="width:92%"><span
                                                                        class="bt_bb_progress_bar_text">Effective
                                                                        results</span></div>
                                                            </div>
                                                            <div
                                                                class="bt_bb_separator bt_bb_top_spacing_small bt_bb_border_style_none">
                                                            </div>
                                                            <div
                                                                class="bt_bb_progress_bar bt_bb_color_scheme_3 bt_bb_align_inherit bt_bb_size_normal bt_bb_style_line bt_bb_shape_rounded">
                                                                <div class="bt_bb_progress_bar_bg"></div>
                                                                <div class="bt_bb_progress_bar_inner animate"
                                                                    style="width:95%"><span
                                                                        class="bt_bb_progress_bar_text">Projects
                                                                        Success</span></div>
                                                            </div>
                                                            <div
                                                                class="bt_bb_separator bt_bb_top_spacing_small bt_bb_border_style_none">
                                                            </div>
                                                            <div
                                                                class="bt_bb_progress_bar bt_bb_color_scheme_3 bt_bb_align_inherit bt_bb_size_normal bt_bb_style_line bt_bb_shape_rounded">
                                                                <div class="bt_bb_progress_bar_bg"></div>
                                                                <div class="bt_bb_progress_bar_inner animate"
                                                                    style="width:89%"><span
                                                                        class="bt_bb_progress_bar_text">Fast problem
                                                                        solving</span></div>
                                                            </div>
                                                            <div
                                                                class="bt_bb_separator bt_bb_top_spacing_small bt_bb_border_style_none">
                                                            </div>
                                                            <div
                                                                class="bt_bb_progress_bar bt_bb_color_scheme_3 bt_bb_align_inherit bt_bb_size_normal bt_bb_style_line bt_bb_shape_rounded">
                                                                <div class="bt_bb_progress_bar_bg"></div>
                                                                <div class="bt_bb_progress_bar_inner animate"
                                                                    style="width:99%"><span
                                                                        class="bt_bb_progress_bar_text">Teamwork</span>
                                                                </div>
                                                            </div>
                                                            <div
                                                                class="bt_bb_separator bt_bb_bottom_spacing_normal bt_bb_border_style_none">
                                                            </div>
                                                            <div
                                                                class="bt_bb_image bt_bb_shape_square bt_bb_align_inherit bt_bb_hover_style_simple bt_bb_content_display_always bt_bb_content_align_middle">
                                                                <span><img
                                                                        src="../wp-content/plugins/bold-page-builder/img/blank.gif"
                                                                        data-full_image_src="http://avantage.bold-themes.com/marketing/wp-content/uploads/sites/4/2019/04/blog-post-08.jpg"
                                                                        data-image_src="http://avantage.bold-themes.com/marketing/wp-content/uploads/sites/4/2019/04/blog-post-08.jpg"
                                                                        title="blog-post-08"
                                                                        alt="http://avantage.bold-themes.com/marketing/wp-content/uploads/sites/4/2019/04/blog-post-08.jpg"
                                                                        class="btLazyLoadImage"></span></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <section id="bt_bb_section5fb501bac3770"
                    class="bt_bb_section bt_bb_top_spacing_large bt_bb_layout_boxed_1200 bt_bb_vertical_align_top">
                    <div class="bt_bb_port">
                        <div class="bt_bb_cell">
                            <div class="bt_bb_cell_inner">
                                <div class="bt_bb_row_wrapper">
                                    <div class="bt_bb_row">
                                        <div class="bt_bb_column col-md-6 col-sm-12 bt_bb_align_left bt_bb_vertical_align_bottom bt_bb_animation_fade_in animate bt_bb_padding_normal"
                                            data-width="6">
                                            <div class="bt_bb_column_content">
                                                <header
                                                    class="bt_bb_headline bt_bb_dash_top bt_bb_size_large bt_bb_superheadline bt_bb_align_inherit">
                                                    <div class="bt_bb_headline_superheadline_outside"><span
                                                            class="bt_bb_headline_superheadline">WHAT CAN WE
                                                            OFFER</span></div>
                                                    <h2><span class="bt_bb_headline_content"><span><b>Services</b><br />
                                                                <u>We're offering</u></span></span>
                                                    </h2>
                                                </header>
                                                <div
                                                    class="bt_bb_separator bt_bb_bottom_spacing_medium bt_bb_border_style_none">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="bt_bb_column col-md-6 col-sm-12 bt_bb_align_right bt_bb_vertical_align_bottom bt_bb_animation_fade_in animate bt_bb_padding_normal"
                                            data-width="6">
                                            <div class="bt_bb_column_content">
                                                <div
                                                    class="bt_bb_button bt_bb_icon_position_right bt_bb_color_scheme_6 bt_bb_style_filled bt_bb_size_normal bt_bb_width_inline bt_bb_shape_slanted_right bt_bb_align_inherit">
                                                    <a href="<?php echo e(url('/services')); ?>" target="_self" class="bt_bb_link"
                                                        title="View all Services"><span class="bt_bb_button_text">View
                                                            all Services</span><span data-ico-fontawesome="&#xf0a9;"
                                                            class="bt_bb_icon_holder"></span></a></div>
                                                <div
                                                    class="bt_bb_separator bt_bb_bottom_spacing_medium bt_bb_border_style_none">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="bt_bb_row_wrapper">
                                    <div class="bt_bb_row bt_bb_column_gap_15">
                                        <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="bt_bb_column col-md-3 col-sm-6 col-ms-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_animation_fade_in zoom_out animate bt_bb_padding_normal"
                                                data-width="3">
                                                <div class="bt_bb_column_content">
                                                    <div
                                                        class="bt_bb_service bt_bb_color_scheme_4 bt_bb_style_filled bt_bb_size_large bt_bb_shape_slanted_right bt_bb_align_inherit bt_bb_highlight_service_true">
                                                        <a href="#" target="_self" title="Internet Marketing"
                                                            data-ico-businessmanagement="<?php
                                                                echo $data->icon;
                                                            ?>"
                                                            class="bt_bb_icon_holder"></a>
                                                        <div class="bt_bb_service_content">
                                                            <div class="bt_bb_service_content_title"><a href="#"
                                                                    target="_self"><?php echo e($data->title); ?></a></div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="bt_bb_separator bt_bb_bottom_spacing_normal bt_bb_border_style_none bt_bb_hidden_md bt_bb_hidden_lg">
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <section id="bt_bb_section5fb501bac4e78"
                    data-background_image_src="'http://avantage.bold-themes.com/marketing/wp-content/uploads/sites/4/2019/04/bgn-passion.jpg'"
                    class="bt_bb_section bt_bb_top_spacing_medium bt_bb_layout_boxed_1200 bt_bb_vertical_align_top btLazyLoadBackground bt_bb_background_image bt_bb_section_show_right_boxed_content"
                    style="background-image:url(http_/avantage.bold-themes.com/marketing/wp-content/plugins/bold-page-builder/img/blank.html);background-position:center bottom;background-size:cover;">
                    <div class="bt_bb_port">
                        <div class="bt_bb_cell">
                            <div class="bt_bb_cell_inner">
                                <div class="bt_bb_row_wrapper">
                                    <div class="bt_bb_row">
                                        <div class="bt_bb_column col-md-6 col-sm-12 bt_bb_align_right bt_bb_vertical_align_bottom bt_bb_animation_fade_in zoom_out animate bt_bb_padding_normal"
                                            data-width="6">
                                            <div class="bt_bb_column_content">
                                                <div
                                                    class="bt_bb_image bt_bb_shape_square bt_bb_align_inherit bt_bb_hover_style_simple bt_bb_content_display_always bt_bb_content_align_middle bt_bb_hidden_xs bt_bb_hidden_ms bt_bb_hidden_sm">
                                                    <span><img
                                                            src="<?php echo e(url('assets/web/assests/wp-content/uploads/sites/4/2019/04/img-passion-768x840.png')); ?>"
                                                            data-full_image_src="http://avantage.bold-themes.com/marketing/wp-content/uploads/sites/4/2019/04/img-passion.png"
                                                            title="img-passion"
                                                            alt="http://avantage.bold-themes.com/marketing/wp-content/uploads/sites/4/2019/04/img-passion-768x840.png"></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="bt_bb_column col-md-6 col-sm-12 bt_bb_align_left bt_bb_vertical_align_bottom bt_bb_animation_fade_in animate bt_bb_padding_normal"
                                            data-width="6">
                                            <div class="bt_bb_column_content">
                                                <header
                                                    class="bt_bb_headline bt_bb_dash_top bt_bb_size_large bt_bb_superheadline bt_bb_subheadline bt_bb_align_inherit">
                                                    <div class="bt_bb_headline_superheadline_outside"><span
                                                            class="bt_bb_headline_superheadline">TOTALLY COMMITED</span>
                                                    </div>
                                                    <h2><span class="bt_bb_headline_content"><span><b>Digital
                                                                    Marketing</b><br />
                                                                <u>Is Our Passion</u></span></span>
                                                    </h2>
                                                    <div class="bt_bb_headline_subheadline">78% of CEO’s believe
                                                        marketers don’t focus on ROI, we do. Our priorities have always
                                                        remained the same: to help companies maximize their marketing
                                                        ROI, accelerate customer growth, and gain a lasting competitive
                                                        edge in their industries.</div>
                                                </header>
                                                <div
                                                    class="bt_bb_separator bt_bb_top_spacing_small bt_bb_bottom_spacing_normal bt_bb_border_style_none">
                                                </div>
                                                <div class="bt_bb_row_inner bt_bb_column_inner_gap_10">
                                                    <div class="bt_bb_column_inner col-md-4 col-ms-12 bt_bb_align_center bt_bb_vertical_align_top bt_bb_padding_double"
                                                        data-width="4">
                                                        <div class="bt_bb_column_inner_content">
                                                            <div
                                                                class="bt_bb_icon bt_bb_color_scheme_3 bt_bb_style_borderless bt_bb_size_xlarge bt_bb_shape_circle bt_bb_align_inherit">
                                                                <span data-ico-businessandfinance="&#xe90e;"
                                                                    class="bt_bb_icon_holder"></span></div>
                                                            <div
                                                                class="bt_bb_separator bt_bb_bottom_spacing_normal bt_bb_border_style_none">
                                                            </div>
                                                            <div class="bt_bb_counter_holder bt_bb_size_large"><span
                                                                    class="bt_bb_counter animate"
                                                                    data-digit-length="4"><span class="onedigit p4 d5"
                                                                        data-digit="5"><span class="n0">0</span><span
                                                                            class="n1">1</span><span
                                                                            class="n2">2</span><span
                                                                            class="n3">3</span><span
                                                                            class="n4">4</span><span
                                                                            class="n5">5</span><span
                                                                            class="n6">6</span><span
                                                                            class="n7">7</span><span
                                                                            class="n8">8</span><span
                                                                            class="n9">9</span><span
                                                                            class="n0">0</span></span><span
                                                                        class="onedigit p3 d0" data-digit="0"><span
                                                                            class="n0">0</span><span
                                                                            class="n1">1</span><span
                                                                            class="n2">2</span><span
                                                                            class="n3">3</span><span
                                                                            class="n4">4</span><span
                                                                            class="n5">5</span><span
                                                                            class="n6">6</span><span
                                                                            class="n7">7</span><span
                                                                            class="n8">8</span><span
                                                                            class="n9">9</span><span
                                                                            class="n0">0</span></span><span
                                                                        class="onedigit p2 d0" data-digit="0"><span
                                                                            class="n0">0</span><span
                                                                            class="n1">1</span><span
                                                                            class="n2">2</span><span
                                                                            class="n3">3</span><span
                                                                            class="n4">4</span><span
                                                                            class="n5">5</span><span
                                                                            class="n6">6</span><span
                                                                            class="n7">7</span><span
                                                                            class="n8">8</span><span
                                                                            class="n9">9</span><span
                                                                            class="n0">0</span></span><span
                                                                        class="onedigit p1 d+" data-digit="+"><span
                                                                            class="t">+</span></span></span></div>
                                                            <div
                                                                class="bt_bb_separator bt_bb_bottom_spacing_extra_small bt_bb_border_style_none">
                                                            </div>
                                                            <div class="bt_bb_text">
                                                                <p style="font-size: .875em;">Business advices given
                                                                    over 30 years</p>
                                                            </div>
                                                            <div
                                                                class="bt_bb_separator bt_bb_bottom_spacing_normal bt_bb_border_style_none bt_bb_hidden_md bt_bb_hidden_lg">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="bt_bb_column_inner col-md-4 col-ms-12 bt_bb_align_center bt_bb_vertical_align_top bt_bb_padding_double"
                                                        data-width="4">
                                                        <div class="bt_bb_column_inner_content">
                                                            <div
                                                                class="bt_bb_icon bt_bb_color_scheme_3 bt_bb_style_borderless bt_bb_size_xlarge bt_bb_shape_circle bt_bb_align_inherit">
                                                                <span data-ico-businessandfinance="&#xe904;"
                                                                    class="bt_bb_icon_holder"></span></div>
                                                            <div
                                                                class="bt_bb_separator bt_bb_bottom_spacing_normal bt_bb_border_style_none">
                                                            </div>
                                                            <div class="bt_bb_counter_holder bt_bb_size_large"><span
                                                                    class="bt_bb_counter animate"
                                                                    data-digit-length="4"><span class="onedigit p4 d1"
                                                                        data-digit="1"><span class="n0">0</span><span
                                                                            class="n1">1</span><span
                                                                            class="n2">2</span><span
                                                                            class="n3">3</span><span
                                                                            class="n4">4</span><span
                                                                            class="n5">5</span><span
                                                                            class="n6">6</span><span
                                                                            class="n7">7</span><span
                                                                            class="n8">8</span><span
                                                                            class="n9">9</span><span
                                                                            class="n0">0</span></span><span
                                                                        class="onedigit p3 d7" data-digit="7"><span
                                                                            class="n0">0</span><span
                                                                            class="n1">1</span><span
                                                                            class="n2">2</span><span
                                                                            class="n3">3</span><span
                                                                            class="n4">4</span><span
                                                                            class="n5">5</span><span
                                                                            class="n6">6</span><span
                                                                            class="n7">7</span><span
                                                                            class="n8">8</span><span
                                                                            class="n9">9</span><span
                                                                            class="n0">0</span></span><span
                                                                        class="onedigit p2 d0" data-digit="0"><span
                                                                            class="n0">0</span><span
                                                                            class="n1">1</span><span
                                                                            class="n2">2</span><span
                                                                            class="n3">3</span><span
                                                                            class="n4">4</span><span
                                                                            class="n5">5</span><span
                                                                            class="n6">6</span><span
                                                                            class="n7">7</span><span
                                                                            class="n8">8</span><span
                                                                            class="n9">9</span><span
                                                                            class="n0">0</span></span><span
                                                                        class="onedigit p1 d+" data-digit="+"><span
                                                                            class="t">+</span></span></span></div>
                                                            <div
                                                                class="bt_bb_separator bt_bb_bottom_spacing_extra_small bt_bb_border_style_none">
                                                            </div>
                                                            <div class="bt_bb_text">
                                                                <p style="font-size: .875em;">Businesses guided over
                                                                    thirty years</p>
                                                            </div>
                                                            <div
                                                                class="bt_bb_separator bt_bb_bottom_spacing_normal bt_bb_border_style_none bt_bb_hidden_md bt_bb_hidden_lg">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="bt_bb_column_inner col-md-4 col-ms-12 bt_bb_align_center bt_bb_vertical_align_top bt_bb_padding_double"
                                                        data-width="4">
                                                        <div class="bt_bb_column_inner_content">
                                                            <div
                                                                class="bt_bb_icon bt_bb_color_scheme_3 bt_bb_style_borderless bt_bb_size_xlarge bt_bb_shape_circle bt_bb_align_inherit">
                                                                <span data-ico-businessandfinance="&#xe918;"
                                                                    class="bt_bb_icon_holder"></span></div>
                                                            <div
                                                                class="bt_bb_separator bt_bb_bottom_spacing_normal bt_bb_border_style_none">
                                                            </div>
                                                            <div class="bt_bb_counter_holder bt_bb_size_large"><span
                                                                    class="bt_bb_counter animate"
                                                                    data-digit-length="3"><span class="onedigit p3 d3"
                                                                        data-digit="3"><span class="n0">0</span><span
                                                                            class="n1">1</span><span
                                                                            class="n2">2</span><span
                                                                            class="n3">3</span><span
                                                                            class="n4">4</span><span
                                                                            class="n5">5</span><span
                                                                            class="n6">6</span><span
                                                                            class="n7">7</span><span
                                                                            class="n8">8</span><span
                                                                            class="n9">9</span><span
                                                                            class="n0">0</span></span><span
                                                                        class="onedigit p2 d0" data-digit="0"><span
                                                                            class="n0">0</span><span
                                                                            class="n1">1</span><span
                                                                            class="n2">2</span><span
                                                                            class="n3">3</span><span
                                                                            class="n4">4</span><span
                                                                            class="n5">5</span><span
                                                                            class="n6">6</span><span
                                                                            class="n7">7</span><span
                                                                            class="n8">8</span><span
                                                                            class="n9">9</span><span
                                                                            class="n0">0</span></span><span
                                                                        class="onedigit p1 d+" data-digit="+"><span
                                                                            class="t">+</span></span></span></div>
                                                            <div
                                                                class="bt_bb_separator bt_bb_bottom_spacing_extra_small bt_bb_border_style_none">
                                                            </div>
                                                            <div class="bt_bb_text">
                                                                <p style="font-size: .875em;">Business Excellence awards
                                                                    achieved</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div
                                                    class="bt_bb_separator bt_bb_bottom_spacing_large bt_bb_border_style_none bt_bb_hidden_xs bt_bb_hidden_ms bt_bb_hidden_sm">
                                                </div>
                                                <div
                                                    class="bt_bb_separator bt_bb_bottom_spacing_medium bt_bb_border_style_none bt_bb_hidden_md bt_bb_hidden_lg">
                                                </div>
                                                <div
                                                    class="bt_bb_image bt_bb_shape_square bt_bb_align_inherit bt_bb_hover_style_simple bt_bb_content_display_always bt_bb_content_align_middle bt_bb_hidden_md bt_bb_hidden_lg">
                                                    <span><img
                                                            src="../wp-content/plugins/bold-page-builder/img/blank.gif"
                                                            data-full_image_src="http://avantage.bold-themes.com/marketing/wp-content/uploads/sites/4/2019/04/img-passion.png"
                                                            data-image_src="http://avantage.bold-themes.com/marketing/wp-content/uploads/sites/4/2019/04/img-passion-768x840.png"
                                                            title="img-passion"
                                                            alt="http://avantage.bold-themes.com/marketing/wp-content/uploads/sites/4/2019/04/img-passion-768x840.png"
                                                            class="btLazyLoadImage"></span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <section id="bt_bb_section5fb501bac7936"
                    class="bt_bb_section bt_bb_top_spacing_large bt_bb_bottom_spacing_large bt_bb_color_scheme_1 bt_bb_layout_boxed_1200 bt_bb_vertical_align_top"
                    style=";background-color:#26272a;">
                    <div class="bt_bb_port">
                        <div class="bt_bb_cell">
                            <div class="bt_bb_cell_inner">
                                <div class="bt_bb_row_wrapper">
                                    <div class="bt_bb_row">
                                        <div class="bt_bb_column col-md-12 col-ms-12 bt_bb_align_center bt_bb_vertical_align_middle bt_bb_animation_fade_in animate bt_bb_padding_double"
                                            data-width="12">
                                            <div class="bt_bb_column_content">
                                                <header
                                                    class="bt_bb_headline bt_bb_dash_top bt_bb_size_large bt_bb_superheadline bt_bb_align_inherit">
                                                    <div class="bt_bb_headline_superheadline_outside"><span
                                                            class="bt_bb_headline_superheadline">YOU'RE IN GOOD
                                                            COMPANY</span></div>
                                                    <h2><span class="bt_bb_headline_content"><span><b>Real
                                                                    People</b><br />
                                                                Real Solutions</span></span>
                                                    </h2>
                                                </header>
                                                <div
                                                    class="bt_bb_separator bt_bb_bottom_spacing_medium bt_bb_border_style_none">
                                                </div>
                                                <div
                                                    class="bt_bb_content_slider bt_bb_gap_large bt_bb_arrows_size_no_arrows bt_bb_show_dots_below bt_bb_height_auto bt_bb_animation_slide bt_bb_multiple_slides bt_bb_dots_style_accent_dot">
                                                    <div class="slick-slider"
                                                        data-slick='{ "lazyLoad": "progressive", "cssEase": "ease-out", "speed": "600", "arrows": false, "adaptiveHeight": true, "dots": true,"slidesToShow": 3,"autoplay": true, "autoplaySpeed": 3000, "responsive": [{ "breakpoint": 480, "settings": { "slidesToShow": 1, "slidesToScroll": 1 } },{ "breakpoint": 768, "settings": { "slidesToShow": 2, "slidesToScroll": 2 } }]}'>
                                                        <div class="bt_bb_content_slider_item" style="">
                                                            <div class="bt_bb_content_slider_item_content content">
                                                                <div
                                                                    class="bt_bb_icon bt_bb_color_scheme_6 bt_bb_style_filled bt_bb_size_large bt_bb_shape_slanted_right bt_bb_align_inherit">
                                                                    <span data-ico-corporatemanagement="&#xe909;"
                                                                        class="bt_bb_icon_holder"></span></div>
                                                                <div
                                                                    class="bt_bb_separator bt_bb_bottom_spacing_normal bt_bb_border_style_none">
                                                                </div>
                                                                <header
                                                                    class="bt_bb_headline bt_bb_dash_none bt_bb_size_small bt_bb_align_inherit">
                                                                    <h4><span class="bt_bb_headline_content"><span>Research
                                                                                &#038;<br />
                                                                                Strategy</span></span>
                                                                    </h4>
                                                                </header>
                                                                <div
                                                                    class="bt_bb_separator bt_bb_bottom_spacing_small bt_bb_border_style_none">
                                                                </div>
                                                                <div class="bt_bb_text">
                                                                    <p>Nanotechnology immersion along the information
                                                                        highway will close the loop on focusing solely
                                                                        on the bottom line.</p>
                                                                </div>
                                                                <div
                                                                    class="bt_bb_separator bt_bb_bottom_spacing_small bt_bb_border_style_none">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="bt_bb_content_slider_item" style="">
                                                            <div class="bt_bb_content_slider_item_content content">
                                                                <div
                                                                    class="bt_bb_icon bt_bb_color_scheme_6 bt_bb_style_filled bt_bb_size_large bt_bb_shape_slanted_right bt_bb_align_inherit">
                                                                    <span data-ico-corporatemanagement="&#xe901;"
                                                                        class="bt_bb_icon_holder"></span></div>
                                                                <div
                                                                    class="bt_bb_separator bt_bb_bottom_spacing_normal bt_bb_border_style_none">
                                                                </div>
                                                                <header
                                                                    class="bt_bb_headline bt_bb_dash_none bt_bb_size_small bt_bb_align_inherit">
                                                                    <h4><span class="bt_bb_headline_content"><span>Marketing
                                                                                &#038;<br />
                                                                                Advertising</span></span>
                                                                    </h4>
                                                                </header>
                                                                <div
                                                                    class="bt_bb_separator bt_bb_bottom_spacing_small bt_bb_border_style_none">
                                                                </div>
                                                                <div class="bt_bb_text">
                                                                    <p>Quickly disseminate superior deliverables whereas
                                                                        web-enabled applications. Quickly drive
                                                                        clicks-and-mortar catalysts.</p>
                                                                </div>
                                                                <div
                                                                    class="bt_bb_separator bt_bb_bottom_spacing_small bt_bb_border_style_none">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="bt_bb_content_slider_item" style="">
                                                            <div class="bt_bb_content_slider_item_content content">
                                                                <div
                                                                    class="bt_bb_icon bt_bb_color_scheme_6 bt_bb_style_filled bt_bb_size_large bt_bb_shape_slanted_right bt_bb_align_inherit">
                                                                    <span data-ico-corporatemanagement="&#xe903;"
                                                                        class="bt_bb_icon_holder"></span></div>
                                                                <div
                                                                    class="bt_bb_separator bt_bb_bottom_spacing_normal bt_bb_border_style_none">
                                                                </div>
                                                                <header
                                                                    class="bt_bb_headline bt_bb_dash_none bt_bb_size_small bt_bb_align_inherit">
                                                                    <h4><span class="bt_bb_headline_content"><span>Persona<br />
                                                                                Development</span></span>
                                                                    </h4>
                                                                </header>
                                                                <div
                                                                    class="bt_bb_separator bt_bb_bottom_spacing_small bt_bb_border_style_none">
                                                                </div>
                                                                <div class="bt_bb_text">
                                                                    <p>Continually reintermediate integrated processes
                                                                        through technically sound intellectual superior
                                                                        capital.</p>
                                                                </div>
                                                                <div
                                                                    class="bt_bb_separator bt_bb_bottom_spacing_small bt_bb_border_style_none">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="bt_bb_content_slider_item" style="">
                                                            <div class="bt_bb_content_slider_item_content content">
                                                                <div
                                                                    class="bt_bb_icon bt_bb_color_scheme_6 bt_bb_style_filled bt_bb_size_large bt_bb_shape_slanted_right bt_bb_align_inherit">
                                                                    <span data-ico-corporatemanagement="&#xe911;"
                                                                        class="bt_bb_icon_holder"></span></div>
                                                                <div
                                                                    class="bt_bb_separator bt_bb_bottom_spacing_normal bt_bb_border_style_none">
                                                                </div>
                                                                <header
                                                                    class="bt_bb_headline bt_bb_dash_none bt_bb_size_small bt_bb_align_inherit">
                                                                    <h4><span class="bt_bb_headline_content"><span>Customer<br />
                                                                                Insights</span></span>
                                                                    </h4>
                                                                </header>
                                                                <div
                                                                    class="bt_bb_separator bt_bb_bottom_spacing_small bt_bb_border_style_none">
                                                                </div>
                                                                <div class="bt_bb_text">
                                                                    <p>Quickly deploy strategic networks with compelling
                                                                        e-business. Credibly pontificate highly
                                                                        efficient manufactured products.</p>
                                                                </div>
                                                                <div
                                                                    class="bt_bb_separator bt_bb_bottom_spacing_small bt_bb_border_style_none">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="bt_bb_content_slider_item" style="">
                                                            <div class="bt_bb_content_slider_item_content content">
                                                                <div
                                                                    class="bt_bb_icon bt_bb_color_scheme_6 bt_bb_style_filled bt_bb_size_large bt_bb_shape_slanted_right bt_bb_align_inherit">
                                                                    <span data-ico-corporatemanagement="&#xe90f;"
                                                                        class="bt_bb_icon_holder"></span></div>
                                                                <div
                                                                    class="bt_bb_separator bt_bb_bottom_spacing_normal bt_bb_border_style_none">
                                                                </div>
                                                                <header
                                                                    class="bt_bb_headline bt_bb_dash_none bt_bb_size_small bt_bb_align_inherit">
                                                                    <h4><span class="bt_bb_headline_content"><span>Direct<br />
                                                                                Marketing</span></span>
                                                                    </h4>
                                                                </header>
                                                                <div
                                                                    class="bt_bb_separator bt_bb_bottom_spacing_small bt_bb_border_style_none">
                                                                </div>
                                                                <div class="bt_bb_text">
                                                                    <p>Dynamically target high-payoff intellectual
                                                                        capital for customized technologies. Objectively
                                                                        integrate emerging core competencies.</p>
                                                                </div>
                                                                <div
                                                                    class="bt_bb_separator bt_bb_bottom_spacing_small bt_bb_border_style_none">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="bt_bb_content_slider_item" style="">
                                                            <div class="bt_bb_content_slider_item_content content">
                                                                <div
                                                                    class="bt_bb_icon bt_bb_color_scheme_6 bt_bb_style_filled bt_bb_size_large bt_bb_shape_slanted_right bt_bb_align_inherit">
                                                                    <span data-ico-corporatemanagement="&#xe902;"
                                                                        class="bt_bb_icon_holder"></span></div>
                                                                <div
                                                                    class="bt_bb_separator bt_bb_bottom_spacing_normal bt_bb_border_style_none">
                                                                </div>
                                                                <header
                                                                    class="bt_bb_headline bt_bb_dash_none bt_bb_size_small bt_bb_align_inherit">
                                                                    <h4><span class="bt_bb_headline_content"><span>Marketing<br />
                                                                                Automation</span></span>
                                                                    </h4>
                                                                </header>
                                                                <div
                                                                    class="bt_bb_separator bt_bb_bottom_spacing_small bt_bb_border_style_none">
                                                                </div>
                                                                <div class="bt_bb_text">
                                                                    <p>Progressively maintain extensive infomediaries
                                                                        via extensible niches. Dramatically disseminate
                                                                        standardized metrics.</p>
                                                                </div>
                                                                <div
                                                                    class="bt_bb_separator bt_bb_bottom_spacing_small bt_bb_border_style_none">
                                                                </div>
                                                                <div
                                                                    class="bt_bb_separator bt_bb_top_spacing_small bt_bb_bottom_spacing_normal bt_bb_border_style_none">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <!-- <section id="bt_bb_section5fb501bac914c"  class="bt_bb_section bt_bb_top_spacing_large bt_bb_layout_wide bt_bb_vertical_align_top" >
                    <div class="bt_bb_port">
                       <div class="bt_bb_cell">
                          <div class="bt_bb_cell_inner">
                             <div class="bt_bb_row_wrapper">
                                <div  class="bt_bb_row" >
                                   <div  class="bt_bb_column col-md-4 col-ms-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_padding_normal"  data-width="4">
                                      <div class="bt_bb_column_content"></div>
                                   </div>
                                   <div  class="bt_bb_column col-md-4 col-ms-12 bt_bb_align_center bt_bb_vertical_align_top bt_bb_animation_fade_in move_up animate bt_bb_padding_normal"  data-width="4">
                                      <div class="bt_bb_column_content">
                                         <header class="bt_bb_headline bt_bb_dash_top bt_bb_size_large bt_bb_superheadline bt_bb_align_inherit">
                                            <div class="bt_bb_headline_superheadline_outside"><span class="bt_bb_headline_superheadline">CHECK OUT OUR WORK</span></div>
                                            <h2><span class="bt_bb_headline_content"><span><b>Our Marketing</b> <u>Consultancy Cases</u></span></span></h2>
                                         </header>
                                         <div class="bt_bb_separator bt_bb_top_spacing_small bt_bb_bottom_spacing_medium bt_bb_border_style_none"></div>
                                      </div>
                                   </div>
                                   <div  class="bt_bb_column col-md-4 col-ms-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_padding_normal"  data-width="4">
                                      <div class="bt_bb_column_content"></div>
                                   </div>
                                </div>
                             </div>
                             <div class="bt_bb_row_wrapper">
                                <div  class="bt_bb_row" >
                                   <div  class="bt_bb_column col-md-12 col-ms-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_animation_fade_in animate bt_bb_padding_normal"  data-width="12">
                                      <div class="bt_bb_column_content">
                                         <div class="bt_bb_masonry_portfolio_tiles bt_bb_grid_container bt_bb_columns_4 bt_bb_gap_no_gap bt_bb_look_triangular" data-columns="4">
                                            <div class="bt_bb_masonry_portfolio_tiles_content bt_bb_masonry_post_grid_content bt_bb_grid_hide" data-bt-nonce="68dd018887" data-number-portfolio="8" data-format-portfolio="" data-category-portfolio=""  data-post-type="portfolio" data-show-portfolio="a%3A2%3A%7Bs%3A7%3A%22excerpt%22%3Bb%3A1%3Bs%3A5%3A%22title%22%3Bb%3A1%3B%7D">
                                               <div class="bt_bb_grid_sizer"></div>
                                            </div>
                                            <div class="bt_bb_post_grid_loader"><span class="box1"></span><span class="box2"></span><span class="box3"></span><span class="box4"></span><span class="box5"></span></div>
                                         </div>
                                      </div>
                                   </div>
                                </div>
                             </div>
                          </div>
                       </div>
                    </div>
                 </section> -->
                
            </div>
        </div>
        <!-- /boldthemes_content -->
    </div>
    <!-- /contentHolder -->
</div>
<!-- /contentWrap -->



<?php echo $__env->make('Web.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\technow\resources\views/Web/about.blade.php ENDPATH**/ ?>