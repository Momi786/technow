<!DOCTYPE html>
<html lang="en-US" data-bt-theme="Avantage 2.0.1">

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>

		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
		<meta name="mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-capable" content="yes">
	<title>Technow Pakistan  </title>

	<link rel='stylesheet' id='wp-block-library-css'  href='<?php echo e(url('assets/web/assests/wp-includes/css/dist/block-library/style.min5697.css?ver=5.5.3')); ?>' type='text/css' media='all' />

<link rel='stylesheet' id='bt_bb_content_elements-css'  href='<?php echo e(url('assets/web/assests/wp-content/plugins/bold-page-builder/css/front_end/content_elements.crush5697.css?ver=5.5.3')); ?>' type='text/css' media='all' />
<link rel='stylesheet' id='bt_bb_slick-css'  href='<?php echo e(url('assets/web/assests/wp-content/plugins/bold-page-builder/slick/slick5697.css?ver=5.5.3')); ?>' type='text/css' media='all' />
<link rel='stylesheet' id='bold-timeline-css'  href='<?php echo e(url('assets/web/assests/wp-content/plugins/bold-timeline/style5697.css?ver=5.5.3')); ?>' type='text/css' media='all' />



<link rel='stylesheet' id='avantage-style-css'  href='<?php echo e(url('assets/web/assests/wp-content/themes/avantage/style5697.css?ver=5.5.3')); ?>' type='text/css' media='screen' />

<link rel='stylesheet' id='avantage-print-css'  href='<?php echo e(url('assets/web/assests/wp-content/themes/avantage/print5697.css?ver=5.5.3')); ?>' type='text/css' media='print' />

<link rel='stylesheet' id='boldthemes-framework-css'  href='<?php echo e(url('assets/web/assests/wp-content/themes/avantage/framework/css/style5697.css?ver=5.5.3')); ?>' type='text/css' media='all' />





<link rel='shortlink' href='index.html' />





	<link rel="icon" href="<?php echo e(url('assets/web/assests/wp-content/uploads/sites/4/2019/04/favicon.png')); ?>" sizes="32x32" />
<link rel="icon" href="<?php echo e(url('assets/web/assests/wp-content/uploads/sites/4/2019/04/favicon.png')); ?>" sizes="192x192" />
<link rel="apple-touch-icon" href="<?php echo e(url('assets/web/assests/wp-content/uploads/sites/4/2019/04/favicon.png')); ?>" />

<link rel="stylesheet" href="<?php echo e(url('assets/web/assests/style.css')); ?>">

		<style type="text/css" id="wp-custom-css">
			/* Remove overlay on 404 page */
.btErrorPage.bt_bb_section[class*="bt_bb_background_overlay"]:before {
	display: none;
}




</style>

</head>


<body class="home page-template-default page page-id-106 theme-avantage bt_bb_plugin_active bt_bb_fe_preview_toggle woocommerce-no-js btHeadingStyle_default btMenuLeftEnabled btMenuBelowLogo btStickyEnabled btHideHeadline btLightSkin btBelowMenu noBodyPreloader btSlantedRightButtons btLightAlternateHeader btNoSidebar btShopSaleTagDesignSlanted_right &quot;&gt;
&lt;!-- Google Tag Manager (noscript) --&gt;
&lt;noscript&gt;&lt;iframe src=_https_/www.googletagmanager.com/ns522a.html?id=GTM-T7NPPG8%22
height=&quot;0&quot; width=&quot;0&quot; style=&quot;display:none;visibility:hidden&quot;&gt;&lt;/iframe&gt;&lt;/noscript&gt;
&lt;!-- End Google Tag Manager (noscript) --&gt;&lt;br style=&quot;display:none;">

<div class="btPageWrap" id="top">
	<div class="btVerticalHeaderTop">
	   <div class="btVerticalMenuTrigger">
		  &nbsp;
		  <div class="bt_bb_icon"><a href="#" target="_self"   data-ico-fa="&#xf0c9;" class="bt_bb_icon_holder"></a></div>
	   </div>
	   <div class="btLogoArea">
		  <div class="logo">
			 <span>
			 <a href="index.html"><img class="btMainLogo" data-hw="1.9148936170213" src="<?php echo e(url('assets/web/assests/wp-content/uploads/sites/4/2019/04/logo.png')); ?>" alt=""></a>				</span>
		  </div>
		  <!-- /logo -->
	   </div>
	   <!-- /btLogoArea -->
	</div>
	<header class="mainHeader btClear gutter ">
	   <div class="mainHeaderInner">
		  <div class="btLogoArea menuHolder btClear">
			 <div class="port">
				<div class="btHorizontalMenuTrigger">
				   &nbsp;
				   <div class="bt_bb_icon"><a href="#" target="_self"   data-ico-fa="&#xf0c9;" class="bt_bb_icon_holder"></a></div>
				</div>
				<div class="logo">
				   <span>
				   <a href="index.html"><img class="btMainLogo" data-hw="1.9148936170213" src="<?php echo e(url('assets/web/assests/wp-content/uploads/sites/4/2019/04/logo.png')); ?>" alt="Marketing Consulting"></a>						</span>
				</div>
				<!-- /logo -->
				<div class="topBarInLogoArea">
				   <div class="topBarInLogoAreaCell">
					  <div class="btIconWidget  btAccentIconWidget btWidgetWithText">
						 <div class="btIconWidgetIcon"><span  data-ico-businessandfinance="&#xe915;" class="bt_bb_icon_holder"></span></div>
						 <div class="btIconWidgetContent"><span class="btIconWidgetTitle">G Magnolia Park</span><span class="btIconWidgetText">Technow Pakistan</span></div>
					  </div>
					  <div class="btIconWidget  btAccentIconWidget btWidgetWithText">
						 <div class="btIconWidgetIcon"><span  data-ico-businesspeople="&#xe91d;" class="bt_bb_icon_holder"></span></div>
						 <div class="btIconWidgetContent"><span class="btIconWidgetTitle">Monday - Saturday</span><span class="btIconWidgetText">Monday - Saturday</span></div>
					  </div>
				   </div>
				   <!-- /topBarInLogoAreaCell -->
				</div>
				<!-- /topBarInLogoArea -->
			 </div>
			 <!-- /port -->
		  </div>
		  <!-- /menuHolder -->
		  <div class="btBelowLogoArea btClear">
			 <div class="port">
				<div class="menuPort">
				   <div class="topBarInMenu">
					  <div class="topBarInMenuCell">
						 <div class="btTopBox widget_search">
							<div class="btSearch">
							   <div class="bt_bb_icon"><a href="#" target="_self"   data-ico-fa="&#xf002;" class="bt_bb_icon_holder"></a></div>
							   <div class="btSearchInner gutter" role="search">
								  <div class="btSearchInnerContent port">
									 <form action="" method="get">
										 <input type="text" name="s" placeholder="Looking for..." class="untouched">
										<button type="submit" data-icon="&#xf105;"></button>
									 </form>
									 <div class="btSearchInnerClose">
										<div class="bt_bb_icon"><a href="#" target="_self"   data-ico-fa="&#xf00d;" class="bt_bb_icon_holder"></a></div>
									 </div>
								  </div>
							   </div>
							</div>
						 </div>
						 <div class="btTopBox woocommerce widget_shopping_cart">
							<h2 class="widgettitle">Cart</h2>
							<div class="widget_shopping_cart_content"></div>
						 </div>
						 <div class="btBox widget_bt_button_widget btIconWidget  btIconWidgetLeft"><a href="tel:+92 345 66770000" target="_self" class="bt_button_widget bt_bb_button_link bt_button_widget_accent" title="020 7946 0020"><span class="bt_bb_button_text">+92 345 6670000</span><span  data-ico-fontawesome="&#xf095;" class="bt_bb_icon_holder"></span></a></div>
					  </div>
					  <!-- /topBarInMenu -->
				   </div>
				   <!-- /topBarInMenuCell -->
				   <nav>
					  <ul id="menu-primary-menu" class="menu">
						 <li id="menu-item-200" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-106 current_page_item current-menu-ancestor current-menu-parent current_page_parent current_page_ancestor menu-item-has-children menu-item-200"><a href="<?php echo e(url('/')); ?>" aria-current="page">Home</a>
						 </li>
						 <li id="menu-item-207" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-207"><a href="<?php echo e(url('/about')); ?>">About us</a>
						 </li>
						 <li id="menu-item-217" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-217"><a href="<?php echo e(url('/team')); ?>">Team</a>
						 </li>
						 <li id="menu-item-224" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-224"><a href="<?php echo e(url('/services')); ?>">Services</a>
						 </li>
					  </ul>
				   </nav>
				</div>
				<!-- .menuPort -->
			 </div>
			 <!-- /port -->
		  </div>
		  <!-- /menuHolder / btBelowLogoArea -->
	   </div>
	   <!-- / inner header for scrolling -->
	</header>
	<!-- /.mainHeader -->
<?php /**PATH C:\xampp\htdocs\technow\resources\views/Web/include/header.blade.php ENDPATH**/ ?>