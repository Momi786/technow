<?php echo $__env->make('Web.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="btContentWrap btClear">
    <div class="btContentHolder">
       <div class="btContent">
          <div class="bt_bb_wrapper">
             <section id="bt_bb_section5fb501c74b80b"  data-background_image_src="'http://avantage.bold-themes.com/marketing/wp-content/uploads/sites/4/2019/05/bgn-services.jpg'" class="bt_bb_section bt_bb_top_spacing_extra_large bt_bb_bottom_spacing_large bt_bb_color_scheme_6 bt_bb_layout_boxed_1200 bt_bb_vertical_align_top btLazyLoadBackground bt_bb_background_image" style="background-image:url(http_/avantage.bold-themes.com/marketing/wp-content/plugins/bold-page-builder/img/blank.html);;background-color:#e6aa3f;">
                <div class="bt_bb_port">
                   <div class="bt_bb_cell">
                      <div class="bt_bb_cell_inner">
                         <div class="bt_bb_row_wrapper">
                            <div  class="bt_bb_row" >
                               <div  class="bt_bb_column col-md-12 col-ms-12 bt_bb_align_left bt_bb_vertical_align_bottom bt_bb_animation_fade_in animate bt_bb_padding_normal"  data-width="12">
                                  <div class="bt_bb_column_content">
                                     <div class="bt_bb_separator bt_bb_bottom_spacing_normal bt_bb_border_style_none"></div>
                                     <header class="bt_bb_headline bt_bb_dash_top bt_bb_size_large bt_bb_superheadline bt_bb_align_inherit">
                                        <div class="bt_bb_headline_superheadline_outside"><span class="bt_bb_headline_superheadline">WHAT CAN WE OFFER</span></div>
                                        <h2><span class="bt_bb_headline_content"><span><s><em>Services</em></s><br />
                                           <u>We're offering</u></span></span>
                                        </h2>
                                     </header>
                                     <div class="bt_bb_separator bt_bb_bottom_spacing_medium bt_bb_border_style_none"></div>
                                  </div>
                               </div>
                            </div>
                         </div>
                         <div class="bt_bb_row_wrapper">
                            <div  class="bt_bb_row bt_bb_column_gap_15" >
                                <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div  class="bt_bb_column col-md-3 col-sm-6 col-ms-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_animation_fade_in zoom_out animate bt_bb_padding_normal"  data-width="3">
                                        <div class="bt_bb_column_content">
                                        <div class="bt_bb_service bt_bb_color_scheme_8 bt_bb_style_filled bt_bb_size_large bt_bb_shape_slanted_right bt_bb_align_inherit bt_bb_highlight_service_true">
                                            <span  data-ico-businessmanagement="<?php echo $data->icon; ?>" class="bt_bb_icon_holder"></span>
                                            <div class="bt_bb_service_content">
                                                <div class="bt_bb_service_content_title"><?php echo e($data->title); ?></div>
                                            </div>
                                        </div>
                                        <div class="bt_bb_separator bt_bb_bottom_spacing_normal bt_bb_border_style_none"></div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                         </div>
                      </div>
                   </div>
                </div>
             </section>



             <section id="bt_bb_section5fb501c75d3c4"  data-background_image_src="''" class="bt_bb_section bt_bb_top_spacing_large bt_bb_bottom_spacing_large bt_bb_layout_boxed_1200 bt_bb_vertical_align_top btLazyLoadBackground bt_bb_background_image" >
                <div class="bt_bb_port">
                   <div class="bt_bb_cell">
                      <div class="bt_bb_cell_inner">
                         <div class="bt_bb_row_wrapper">
                            <div  class="bt_bb_row" >
                               <div  class="bt_bb_column col-md-6 col-sm-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_animation_fade_in animate bt_bb_padding_normal"  data-width="6">
                                  <div class="bt_bb_column_content">
                                     <header class="bt_bb_headline bt_bb_dash_top bt_bb_size_large bt_bb_superheadline bt_bb_align_inherit">
                                        <div class="bt_bb_headline_superheadline_outside"><span class="bt_bb_headline_superheadline">WHAT CAN WE OFFER</span></div>
                                        <h2><span class="bt_bb_headline_content"><span><b>Avantage</b><br />
                                           <u>Packages & Pricing</u></span></span>
                                        </h2>
                                     </header>
                                     <div class="bt_bb_separator bt_bb_bottom_spacing_medium bt_bb_border_style_none"></div>
                                  </div>
                               </div>
                               <div  class="bt_bb_column col-md-6 col-sm-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_padding_normal"  data-width="6">
                                  <div class="bt_bb_column_content"></div>
                               </div>
                            </div>
                         </div>
                         <div class="bt_bb_row_wrapper">
                            <div  class="bt_bb_row bt_bb_column_gap_10" >
                               <div  class="bt_bb_column col-md-4 col-ms-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_animation_fade_in zoom_out animate bt_bb_padding_normal"  data-width="4">
                                  <div class="bt_bb_column_content">
                                     <div class="bt_bb_separator bt_bb_top_spacing_normal bt_bb_bottom_spacing_normal bt_bb_border_style_none"></div>
                                     <div class="bt_bb_price_list bt_bb_color_scheme_5" style=";background-color:#f1f1f1;">
                                        <div class="bt_bb_icon bt_bb_style_filled bt_bb_size_large bt_bb_shape_slanted_right bt_bb_vertical_position_half_above"><span  data-ico-businessandfinance="&#xe914;" class="bt_bb_icon_holder"></span></div>
                                        <div class="bt_bb_price_list_title_subtitle_price">
                                           <div class="bt_bb_price_list_title_wrap">
                                              <div class="bt_bb_price_list_price"><span class="bt_bb_price_list_currency">$</span><span class="bt_bb_price_list_amount">146</span></div>
                                              <div class="bt_bb_price_list_title_subtitle">
                                                 <div class="bt_bb_price_list_subtitle">STARTER PACKAGE</div>
                                                 <div class="bt_bb_price_list_title">Website Optimization</div>
                                              </div>
                                           </div>
                                        </div>
                                        <ul>
                                           <li>Basic website checkup</li>
                                           <li>SEO recommendations</li>
                                           <li>Google Ads recommendations</li>
                                           <li>W3C Validator recommendations</li>
                                        </ul>
                                     </div>
                                     <div class="bt_bb_separator bt_bb_top_spacing_extra_small bt_bb_bottom_spacing_small bt_bb_border_style_none"></div>
                                     <div class="bt_bb_button bt_bb_icon_position_right bt_bb_color_scheme_6 bt_bb_style_filled bt_bb_size_normal bt_bb_width_inline bt_bb_shape_inherit bt_bb_align_right" style="margin-right: 1.875em"><a href="#" target="_self" class="bt_bb_link" title="Buy now"><span class="bt_bb_button_text">Buy now</span><span  data-ico-fontawesome="&#xf0a9;" class="bt_bb_icon_holder"></span></a></div>
                                     <div class="bt_bb_separator bt_bb_bottom_spacing_small bt_bb_border_style_none"></div>
                                  </div>
                               </div>
                               <div  class="bt_bb_column col-md-4 col-ms-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_animation_fade_in zoom_out animate bt_bb_padding_normal"  data-width="4">
                                  <div class="bt_bb_column_content">
                                     <div class="bt_bb_separator bt_bb_top_spacing_normal bt_bb_bottom_spacing_normal bt_bb_border_style_none"></div>
                                     <div class="bt_bb_price_list bt_bb_color_scheme_11" style=";background-color:#e49f37;">
                                        <div class="bt_bb_icon bt_bb_style_filled bt_bb_size_large bt_bb_shape_slanted_right bt_bb_vertical_position_half_above"><span  data-ico-businessandfinance="&#xe917;" class="bt_bb_icon_holder"></span></div>
                                        <div class="bt_bb_price_list_title_subtitle_price">
                                           <div class="bt_bb_price_list_title_wrap">
                                              <div class="bt_bb_price_list_price"><span class="bt_bb_price_list_currency">$</span><span class="bt_bb_price_list_amount">199</span></div>
                                              <div class="bt_bb_price_list_title_subtitle">
                                                 <div class="bt_bb_price_list_subtitle">UPGRADED PACKAGE</div>
                                                 <div class="bt_bb_price_list_title">Marketing &amp; Optimization</div>
                                              </div>
                                           </div>
                                        </div>
                                        <ul>
                                           <li>Website checkup (W3C included)</li>
                                           <li>SEO changes</li>
                                           <li>Google Ads basic plan</li>
                                           <li>Social Media plan</li>
                                        </ul>
                                     </div>
                                     <div class="bt_bb_separator bt_bb_top_spacing_extra_small bt_bb_bottom_spacing_small bt_bb_border_style_none"></div>
                                     <div class="bt_bb_button bt_bb_icon_position_right bt_bb_color_scheme_11 bt_bb_style_filled bt_bb_size_normal bt_bb_width_inline bt_bb_shape_inherit bt_bb_align_right" style="margin-right: 1.875em"><a href="#" target="_self" class="bt_bb_link" title="Buy now"><span class="bt_bb_button_text">Buy now</span><span  data-ico-fontawesome="&#xf0a9;" class="bt_bb_icon_holder"></span></a></div>
                                     <div class="bt_bb_separator bt_bb_bottom_spacing_small bt_bb_border_style_none"></div>
                                  </div>
                               </div>
                               <div  class="bt_bb_column col-md-4 col-ms-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_animation_fade_in zoom_out animate bt_bb_padding_normal"  data-width="4">
                                  <div class="bt_bb_column_content">
                                     <div class="bt_bb_separator bt_bb_top_spacing_normal bt_bb_bottom_spacing_normal bt_bb_border_style_none"></div>
                                     <div class="bt_bb_price_list bt_bb_color_scheme_5" style=";background-color:#f1f1f1;">
                                        <div class="bt_bb_icon bt_bb_style_filled bt_bb_size_large bt_bb_shape_slanted_right bt_bb_vertical_position_half_above"><span  data-ico-businessandfinance="&#xe918;" class="bt_bb_icon_holder"></span></div>
                                        <div class="bt_bb_price_list_title_subtitle_price">
                                           <div class="bt_bb_price_list_title_wrap">
                                              <div class="bt_bb_price_list_price"><span class="bt_bb_price_list_currency">$</span><span class="bt_bb_price_list_amount">299</span></div>
                                              <div class="bt_bb_price_list_title_subtitle">
                                                 <div class="bt_bb_price_list_subtitle">FULL PACKAGE</div>
                                                 <div class="bt_bb_price_list_title">Complete Website Strategy</div>
                                              </div>
                                           </div>
                                        </div>
                                        <ul>
                                           <li>Website checkup (W3C included)</li>
                                           <li>SEO changes</li>
                                           <li>Google Ads marketing plan</li>
                                           <li>Social Media marketing plan</li>
                                        </ul>
                                     </div>
                                     <div class="bt_bb_separator bt_bb_top_spacing_extra_small bt_bb_bottom_spacing_small bt_bb_border_style_none"></div>
                                     <div class="bt_bb_button bt_bb_icon_position_right bt_bb_color_scheme_6 bt_bb_style_filled bt_bb_size_normal bt_bb_width_inline bt_bb_shape_inherit bt_bb_align_right" style="margin-right: 1.875em"><a href="#" target="_self" class="bt_bb_link" title="Buy now"><span class="bt_bb_button_text">Buy now</span><span  data-ico-fontawesome="&#xf0a9;" class="bt_bb_icon_holder"></span></a></div>
                                     <div class="bt_bb_separator bt_bb_bottom_spacing_small bt_bb_border_style_none"></div>
                                  </div>
                               </div>
                            </div>
                         </div>
                      </div>
                   </div>
                </div>
             </section>
          </div>
       </div>
       <!-- /boldthemes_content -->
    </div>
    <!-- /contentHolder -->
 </div>

<?php echo $__env->make('Web.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\technow\resources\views/Web/services.blade.php ENDPATH**/ ?>