<?php echo $__env->make('Web.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- /.mainHeader -->
<div class="btContentWrap btClear">
    <div class="btContentHolder">
       <div class="btContent">
          <div class="bt_bb_wrapper">
             <section id="bt_bb_section5fb5013952d29"  class="bt_bb_section bt_bb_color_scheme_1 bt_bb_layout_wide bt_bb_vertical_align_top" style="background-color:#e5a648;">
                <div class="bt_bb_port">
                   <div class="bt_bb_cell">
                      <div class="bt_bb_cell_inner">
                         <div class="bt_bb_row_wrapper">
                            <div  class="bt_bb_row" >
                               <div  class="bt_bb_column col-md-12 col-ms-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_padding_normal"  data-width="12">
                                  <div class="bt_bb_column_content">
                                     <div class="bt_bb_content_slider bt_bb_gap_no_gap bt_bb_arrows_size_large bt_bb_show_dots_bottom bt_bb_height_auto bt_bb_animation_fade bt_bb_dots_style_accent_dot bt_bb_arrows_style_accent_light">
                                        <div class="slick-slider fade"  data-slick='{ "lazyLoad": "progressive", "cssEase": "ease-out", "speed": "600", "fade": true, "prevArrow": "&lt;button type=\"button\" class=\"slick-prev\" aria-label=\"Previous\" tabindex=\"0\" role=\"button\"&gt;&lt;/button&gt;", "nextArrow": "&lt;button type=\"button\" class=\"slick-next\" aria-label=\"Next\" tabindex=\"0\" role=\"button\"&gt;&lt;/button&gt;", "adaptiveHeight": true, "dots": true}' >
                                           <div class="bt_bb_content_slider_item" style="background-position: center bottom;;background-image:url(wp-content/uploads/sites/4/2019/04/img-slider-01.jpg)">
                                              <div class="bt_bb_content_slider_item_content content">
                                                 <div  class="bt_bb_row_inner" >
                                                    <div  class="bt_bb_column_inner col-md-7 col-ms-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_animation_fade_in zoom_out animate bt_bb_padding_normal"  data-width="7">
                                                       <div class="bt_bb_column_inner_content">
                                                          <div class="bt_bb_separator bt_bb_top_spacing_extra_large bt_bb_border_style_none"></div>
                                                          <div class="bt_bb_separator bt_bb_bottom_spacing_normal bt_bb_border_style_none bt_bb_hidden_xs bt_bb_hidden_ms bt_bb_hidden_sm"></div>
                                                          <div class="bt_bb_separator bt_bb_bottom_spacing_medium bt_bb_border_style_none bt_bb_hidden_xs bt_bb_hidden_ms bt_bb_hidden_sm"></div>
                                                          <div class="bt_bb_separator bt_bb_bottom_spacing_medium bt_bb_border_style_none bt_bb_hidden_xs bt_bb_hidden_ms bt_bb_hidden_sm"></div>
                                                          <header class="bt_bb_headline bt_bb_color_scheme_6 bt_bb_dash_top bt_bb_size_huge bt_bb_superheadline bt_bb_align_inherit bt_bb_hidden_xs bt_bb_hidden_ms">
                                                             <div class="bt_bb_headline_superheadline_outside"><span class="bt_bb_headline_superheadline">GET IT RIGHT THE FIRST TIME</span></div>
                                                             <h1><span class="bt_bb_headline_content"><span><s><em>Build an Effective</em></s><br />
                                                                <u>Digital Strategy</u></span></span>
                                                             </h1>
                                                          </header>
                                                          <header class="bt_bb_headline bt_bb_color_scheme_6 bt_bb_dash_top bt_bb_size_large bt_bb_superheadline bt_bb_align_inherit bt_bb_hidden_sm bt_bb_hidden_md bt_bb_hidden_lg">
                                                             <div class="bt_bb_headline_superheadline_outside"><span class="bt_bb_headline_superheadline">GET IT RIGHT THE FIRST TIME</span></div>
                                                             <h1><span class="bt_bb_headline_content"><span><s><em>Build an Effective</em></s> <u>Digital Strategy</u></span></span></h1>
                                                          </header>
                                                          <div class="bt_bb_separator bt_bb_top_spacing_normal bt_bb_bottom_spacing_normal bt_bb_border_style_none"></div>
                                                          <div class="bt_bb_button bt_bb_icon_position_left bt_bb_color_scheme_11 bt_bb_style_filled bt_bb_size_normal bt_bb_width_inline bt_bb_shape_inherit bt_bb_align_inherit"><a href="#" target="_self" class="bt_bb_link" title="How can we help?"><span class="bt_bb_button_text">How can we help?</span></a></div>
                                                          <div class="bt_bb_separator bt_bb_top_spacing_medium bt_bb_bottom_spacing_large bt_bb_border_style_none"></div>
                                                          <div class="bt_bb_separator bt_bb_bottom_spacing_medium bt_bb_border_style_none"></div>
                                                       </div>
                                                    </div>
                                                    <div  class="bt_bb_column_inner col-md-5 col-ms-12 bt_bb_align_left bt_bb_vertical_align_top"  data-width="5">
                                                       <div class="bt_bb_column_inner_content"></div>
                                                    </div>
                                                 </div>
                                              </div>
                                           </div>
                                           <div class="bt_bb_content_slider_item" style="background-position: center bottom;;background-image:url(wp-content/uploads/sites/4/2019/04/img-slider-02.jpg)">
                                              <div class="bt_bb_content_slider_item_content content">
                                                 <div  class="bt_bb_row_inner" >
                                                    <div  class="bt_bb_column_inner col-md-6 col-sm-12 bt_bb_align_left bt_bb_vertical_align_top"  data-width="6">
                                                       <div class="bt_bb_column_inner_content"></div>
                                                    </div>
                                                    <div  class="bt_bb_column_inner col-md-6 col-sm-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_animation_fade_in zoom_out animate bt_bb_padding_normal"  data-width="6">
                                                       <div class="bt_bb_column_inner_content">
                                                          <div class="bt_bb_separator bt_bb_top_spacing_extra_large bt_bb_border_style_none"></div>
                                                          <div class="bt_bb_separator bt_bb_bottom_spacing_normal bt_bb_border_style_none bt_bb_hidden_xs bt_bb_hidden_ms bt_bb_hidden_sm"></div>
                                                          <div class="bt_bb_separator bt_bb_bottom_spacing_medium bt_bb_border_style_none bt_bb_hidden_xs bt_bb_hidden_ms bt_bb_hidden_sm"></div>
                                                          <div class="bt_bb_separator bt_bb_bottom_spacing_medium bt_bb_border_style_none bt_bb_hidden_xs bt_bb_hidden_ms bt_bb_hidden_sm"></div>
                                                          <header class="bt_bb_headline bt_bb_color_scheme_6 bt_bb_dash_top bt_bb_size_huge bt_bb_superheadline bt_bb_align_inherit bt_bb_hidden_xs bt_bb_hidden_ms">
                                                             <div class="bt_bb_headline_superheadline_outside"><span class="bt_bb_headline_superheadline">DON&#8217;T THINK BIG, THINK HUGE</span></div>
                                                             <h1><span class="bt_bb_headline_content"><span><s><em>Brand Builders</em></s><br />
                                                                <u>&#038; Storytellers</u></span></span>
                                                             </h1>
                                                          </header>
                                                          <header class="bt_bb_headline bt_bb_color_scheme_6 bt_bb_dash_top bt_bb_size_large bt_bb_superheadline bt_bb_align_inherit bt_bb_hidden_sm bt_bb_hidden_md bt_bb_hidden_lg">
                                                             <div class="bt_bb_headline_superheadline_outside"><span class="bt_bb_headline_superheadline">DON&#8217;T THINK BIG, THINK HUGE</span></div>
                                                             <h1><span class="bt_bb_headline_content"><span><s><em>Brand Builders</em></s> <u>&#038; Storytellers</u></span></span></h1>
                                                          </header>
                                                          <div class="bt_bb_separator bt_bb_top_spacing_normal bt_bb_bottom_spacing_normal bt_bb_border_style_none"></div>
                                                          <div class="bt_bb_button bt_bb_icon_position_left bt_bb_color_scheme_11 bt_bb_style_filled bt_bb_size_normal bt_bb_width_inline bt_bb_shape_inherit bt_bb_align_inherit"><a href="#" target="_self" class="bt_bb_link" title="View our Services"><span class="bt_bb_button_text">View our Services</span></a></div>
                                                          <div class="bt_bb_separator bt_bb_top_spacing_medium bt_bb_bottom_spacing_large bt_bb_border_style_none"></div>
                                                          <div class="bt_bb_separator bt_bb_bottom_spacing_medium bt_bb_border_style_none"></div>
                                                       </div>
                                                    </div>
                                                 </div>
                                              </div>
                                           </div>
                                           <div class="bt_bb_content_slider_item" style="background-position: center bottom;;background-image:url(wp-content/uploads/sites/4/2019/04/img-slider-03.jpg)">
                                              <div class="bt_bb_content_slider_item_content content">
                                                 <div  class="bt_bb_row_inner" >
                                                    <div  class="bt_bb_column_inner col-md-7 col-ms-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_animation_fade_in zoom_out animate bt_bb_padding_normal"  data-width="7">
                                                       <div class="bt_bb_column_inner_content">
                                                          <div class="bt_bb_separator bt_bb_top_spacing_extra_large bt_bb_border_style_none"></div>
                                                          <div class="bt_bb_separator bt_bb_bottom_spacing_normal bt_bb_border_style_none bt_bb_hidden_xs bt_bb_hidden_ms bt_bb_hidden_sm"></div>
                                                          <div class="bt_bb_separator bt_bb_bottom_spacing_medium bt_bb_border_style_none bt_bb_hidden_xs bt_bb_hidden_ms bt_bb_hidden_sm"></div>
                                                          <div class="bt_bb_separator bt_bb_bottom_spacing_medium bt_bb_border_style_none bt_bb_hidden_xs bt_bb_hidden_ms bt_bb_hidden_sm"></div>
                                                          <header class="bt_bb_headline bt_bb_color_scheme_6 bt_bb_dash_top bt_bb_size_huge bt_bb_superheadline bt_bb_align_inherit bt_bb_hidden_xs bt_bb_hidden_ms">
                                                             <div class="bt_bb_headline_superheadline_outside"><span class="bt_bb_headline_superheadline">CONNECTING CUSTOMERS TO YOUR BRAND</span></div>
                                                             <h1><span class="bt_bb_headline_content"><span><s><em>Building Brands</em></s><br />
                                                                <u>With Great Passion</u></span></span>
                                                             </h1>
                                                          </header>
                                                          <header class="bt_bb_headline bt_bb_color_scheme_6 bt_bb_dash_top bt_bb_size_large bt_bb_superheadline bt_bb_align_inherit bt_bb_hidden_sm bt_bb_hidden_md bt_bb_hidden_lg">
                                                             <div class="bt_bb_headline_superheadline_outside"><span class="bt_bb_headline_superheadline">CONNECTING CUSTOMERS TO YOUR BRAND</span></div>
                                                             <h1><span class="bt_bb_headline_content"><span><s><em>Building Brands</em></s> <u>With Great Passion</u></span></span></h1>
                                                          </header>
                                                          <div class="bt_bb_separator bt_bb_top_spacing_normal bt_bb_bottom_spacing_normal bt_bb_border_style_none"></div>
                                                          <div class="bt_bb_button bt_bb_icon_position_left bt_bb_color_scheme_11 bt_bb_style_filled bt_bb_size_normal bt_bb_width_inline bt_bb_shape_inherit bt_bb_align_inherit"><a href="#" target="_self" class="bt_bb_link" title="View Our Portfolio"><span class="bt_bb_button_text">View Our Portfolio</span></a></div>
                                                          <div class="bt_bb_separator bt_bb_top_spacing_medium bt_bb_bottom_spacing_large bt_bb_border_style_none"></div>
                                                          <div class="bt_bb_separator bt_bb_bottom_spacing_medium bt_bb_border_style_none"></div>
                                                       </div>
                                                    </div>
                                                    <div  class="bt_bb_column_inner col-md-5 col-ms-12 bt_bb_align_left bt_bb_vertical_align_top"  data-width="5">
                                                       <div class="bt_bb_column_inner_content"></div>
                                                    </div>
                                                 </div>
                                              </div>
                                           </div>
                                        </div>
                                     </div>
                                  </div>
                               </div>
                            </div>
                         </div>
                      </div>
                   </div>
                </div>
             </section>
             
             <section id="bt_bb_section5fb50139598a7"  class="bt_bb_section bt_bb_layout_boxed_1200 bt_bb_vertical_align_top bt_bb_section_show_right_boxed_content" >
                <div class="bt_bb_port">
                   <div class="bt_bb_cell">
                      <div class="bt_bb_cell_inner">
                         <div class="bt_bb_row_wrapper">
                            <div  class="bt_bb_row" >
                               <div  class="bt_bb_column col-md-6 col-sm-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_animation_fade_in animate bt_bb_padding_normal bt_bb_mobile_align_to_left_edge"  data-width="6">
                                  <div class="bt_bb_column_content">
                                     <div class="bt_bb_image bt_bb_shape_square bt_bb_align_inherit bt_bb_hover_style_simple bt_bb_content_display_always bt_bb_content_align_middle"><span><img src = "wp-content/plugins/bold-page-builder/img/blank.gif" data-full_image_src="http://avantage.bold-themes.com/marketing/wp-content/uploads/sites/4/2019/04/img-people.jpg" data-image_src="http://avantage.bold-themes.com/marketing/wp-content/uploads/sites/4/2019/04/img-people.jpg" alt="http://avantage.bold-themes.com/marketing/wp-content/uploads/sites/4/2019/04/img-people.jpg" class="btLazyLoadImage"></span></div>
                                     <div class="bt_bb_separator bt_bb_bottom_spacing_normal bt_bb_border_style_none bt_bb_hidden_md bt_bb_hidden_lg"></div>
                                  </div>
                               </div>
                               <div  class="bt_bb_column col-md-6 col-sm-12 bt_bb_align_left bt_bb_vertical_align_middle bt_bb_animation_fade_in animate bt_bb_padding_double btLazyLoadBackground bt_bb_column_background_image" style="background-image:url(http_/avantage.bold-themes.com/marketing/wp-content/plugins/bold-page-builder/img/blank.html);background-position:right center;background-size:auto;" data-background_image_src='http://avantage.bold-themes.com/marketing/wp-content/uploads/sites/4/2019/04/bgn-people.png' data-width="6">
                                  <div class="bt_bb_column_content">
                                     <header class="bt_bb_headline bt_bb_dash_top bt_bb_size_large bt_bb_superheadline bt_bb_align_inherit">
                                        <div class="bt_bb_headline_superheadline_outside"><span class="bt_bb_headline_superheadline">YOU'RE IN GOOD COMPANY</span></div>
                                        <h2><span class="bt_bb_headline_content"><span><b>Real People</b><br />
                                           <u>Real Solutions</u></span></span>
                                        </h2>
                                     </header>
                                     <div class="bt_bb_separator bt_bb_bottom_spacing_medium bt_bb_border_style_none"></div>
                                     <div class="bt_bb_content_slider bt_bb_gap_large bt_bb_arrows_size_no_arrows bt_bb_show_dots_below bt_bb_height_auto bt_bb_animation_slide bt_bb_multiple_slides bt_bb_dots_style_accent_dot">
                                        <div class="slick-slider"  data-slick='{ "lazyLoad": "progressive", "cssEase": "ease-out", "speed": "600", "arrows": false, "adaptiveHeight": true, "dots": true,"slidesToShow": 2,"autoplay": true, "autoplaySpeed": 3000, "responsive": [{ "breakpoint": 480, "settings": { "slidesToShow": 1, "slidesToScroll": 1 } }]}' >
                                           <div class="bt_bb_content_slider_item" style="">
                                              <div class="bt_bb_content_slider_item_content content">
                                                 <div class="bt_bb_icon bt_bb_color_scheme_6 bt_bb_style_filled bt_bb_size_large bt_bb_shape_slanted_right bt_bb_align_inherit"><span  data-ico-corporatemanagement="&#xe909;" class="bt_bb_icon_holder"></span></div>
                                                 <div class="bt_bb_separator bt_bb_bottom_spacing_normal bt_bb_border_style_none"></div>
                                                 <header class="bt_bb_headline bt_bb_dash_none bt_bb_size_small bt_bb_align_inherit">
                                                    <h4><span class="bt_bb_headline_content"><span>Research &#038;<br />
                                                       Strategy</span></span>
                                                    </h4>
                                                 </header>
                                                 <div class="bt_bb_separator bt_bb_bottom_spacing_small bt_bb_border_style_none"></div>
                                                 <div  class="bt_bb_text" >
                                                    <p>Nanotechnology immersion along the information highway will close the loop on focusing solely on the bottom line.</p>
                                                 </div>
                                                 <div class="bt_bb_separator bt_bb_bottom_spacing_small bt_bb_border_style_none"></div>
                                              </div>
                                           </div>
                                           <div class="bt_bb_content_slider_item" style="">
                                              <div class="bt_bb_content_slider_item_content content">
                                                 <div class="bt_bb_icon bt_bb_color_scheme_6 bt_bb_style_filled bt_bb_size_large bt_bb_shape_slanted_right bt_bb_align_inherit"><span  data-ico-corporatemanagement="&#xe901;" class="bt_bb_icon_holder"></span></div>
                                                 <div class="bt_bb_separator bt_bb_bottom_spacing_normal bt_bb_border_style_none"></div>
                                                 <header class="bt_bb_headline bt_bb_dash_none bt_bb_size_small bt_bb_align_inherit">
                                                    <h4><span class="bt_bb_headline_content"><span>Marketing &#038;<br />
                                                       Advertising</span></span>
                                                    </h4>
                                                 </header>
                                                 <div class="bt_bb_separator bt_bb_bottom_spacing_small bt_bb_border_style_none"></div>
                                                 <div  class="bt_bb_text" >
                                                    <p>Quickly disseminate superior deliverables whereas web-enabled applications. Quickly drive clicks-and-mortar catalysts.</p>
                                                 </div>
                                                 <div class="bt_bb_separator bt_bb_bottom_spacing_small bt_bb_border_style_none"></div>
                                              </div>
                                           </div>
                                           <div class="bt_bb_content_slider_item" style="">
                                              <div class="bt_bb_content_slider_item_content content">
                                                 <div class="bt_bb_icon bt_bb_color_scheme_6 bt_bb_style_filled bt_bb_size_large bt_bb_shape_slanted_right bt_bb_align_inherit"><span  data-ico-corporatemanagement="&#xe903;" class="bt_bb_icon_holder"></span></div>
                                                 <div class="bt_bb_separator bt_bb_bottom_spacing_normal bt_bb_border_style_none"></div>
                                                 <header class="bt_bb_headline bt_bb_dash_none bt_bb_size_small bt_bb_align_inherit">
                                                    <h4><span class="bt_bb_headline_content"><span>Persona<br />
                                                       Development</span></span>
                                                    </h4>
                                                 </header>
                                                 <div class="bt_bb_separator bt_bb_bottom_spacing_small bt_bb_border_style_none"></div>
                                                 <div  class="bt_bb_text" >
                                                    <p>Continually reintermediate integrated processes through technically sound intellectual superior capital.</p>
                                                 </div>
                                                 <div class="bt_bb_separator bt_bb_bottom_spacing_small bt_bb_border_style_none"></div>
                                              </div>
                                           </div>
                                           <div class="bt_bb_content_slider_item" style="">
                                              <div class="bt_bb_content_slider_item_content content">
                                                 <div class="bt_bb_icon bt_bb_color_scheme_6 bt_bb_style_filled bt_bb_size_large bt_bb_shape_slanted_right bt_bb_align_inherit"><span  data-ico-corporatemanagement="&#xe911;" class="bt_bb_icon_holder"></span></div>
                                                 <div class="bt_bb_separator bt_bb_bottom_spacing_normal bt_bb_border_style_none"></div>
                                                 <header class="bt_bb_headline bt_bb_dash_none bt_bb_size_small bt_bb_align_inherit">
                                                    <h4><span class="bt_bb_headline_content"><span>Customer<br />
                                                       Insights</span></span>
                                                    </h4>
                                                 </header>
                                                 <div class="bt_bb_separator bt_bb_bottom_spacing_small bt_bb_border_style_none"></div>
                                                 <div  class="bt_bb_text" >
                                                    <p>Quickly deploy strategic networks with compelling e-business. Credibly pontificate highly efficient manufactured products.</p>
                                                 </div>
                                                 <div class="bt_bb_separator bt_bb_bottom_spacing_small bt_bb_border_style_none"></div>
                                              </div>
                                           </div>
                                           <div class="bt_bb_content_slider_item" style="">
                                              <div class="bt_bb_content_slider_item_content content">
                                                 <div class="bt_bb_icon bt_bb_color_scheme_6 bt_bb_style_filled bt_bb_size_large bt_bb_shape_slanted_right bt_bb_align_inherit"><span  data-ico-corporatemanagement="&#xe90f;" class="bt_bb_icon_holder"></span></div>
                                                 <div class="bt_bb_separator bt_bb_bottom_spacing_normal bt_bb_border_style_none"></div>
                                                 <header class="bt_bb_headline bt_bb_dash_none bt_bb_size_small bt_bb_align_inherit">
                                                    <h4><span class="bt_bb_headline_content"><span>Direct<br />
                                                       Marketing</span></span>
                                                    </h4>
                                                 </header>
                                                 <div class="bt_bb_separator bt_bb_bottom_spacing_small bt_bb_border_style_none"></div>
                                                 <div  class="bt_bb_text" >
                                                    <p>Dynamically target high-payoff intellectual capital for customized technologies. Objectively integrate emerging core competencies.</p>
                                                 </div>
                                                 <div class="bt_bb_separator bt_bb_bottom_spacing_small bt_bb_border_style_none"></div>
                                              </div>
                                           </div>
                                           <div class="bt_bb_content_slider_item" style="">
                                              <div class="bt_bb_content_slider_item_content content">
                                                 <div class="bt_bb_icon bt_bb_color_scheme_6 bt_bb_style_filled bt_bb_size_large bt_bb_shape_slanted_right bt_bb_align_inherit"><span  data-ico-corporatemanagement="&#xe902;" class="bt_bb_icon_holder"></span></div>
                                                 <div class="bt_bb_separator bt_bb_bottom_spacing_normal bt_bb_border_style_none"></div>
                                                 <header class="bt_bb_headline bt_bb_dash_none bt_bb_size_small bt_bb_align_inherit">
                                                    <h4><span class="bt_bb_headline_content"><span>Marketing<br />
                                                       Automation</span></span>
                                                    </h4>
                                                 </header>
                                                 <div class="bt_bb_separator bt_bb_bottom_spacing_small bt_bb_border_style_none"></div>
                                                 <div  class="bt_bb_text" >
                                                    <p>Progressively maintain extensive infomediaries via extensible niches. Dramatically disseminate standardized metrics.</p>
                                                 </div>
                                                 <div class="bt_bb_separator bt_bb_bottom_spacing_small bt_bb_border_style_none"></div>
                                              </div>
                                           </div>
                                        </div>
                                     </div>
                                  </div>
                               </div>
                            </div>
                         </div>
                      </div>
                   </div>
                </div>
             </section>
             <section id="bt_bb_section5fb501395ccac"  class="bt_bb_section bt_bb_top_spacing_large bt_bb_bottom_spacing_large bt_bb_layout_boxed_1200 bt_bb_vertical_align_top" >
                <div class="bt_bb_port">
                   <div class="bt_bb_cell">
                      <div class="bt_bb_cell_inner">
                         <div class="bt_bb_row_wrapper">
                            <div  class="bt_bb_row" >
                               <div  class="bt_bb_column col-md-6 col-sm-12 bt_bb_align_left bt_bb_vertical_align_bottom bt_bb_animation_fade_in animate bt_bb_padding_normal"  data-width="6">
                                  <div class="bt_bb_column_content">
                                     <header class="bt_bb_headline bt_bb_dash_top bt_bb_size_large bt_bb_superheadline bt_bb_align_inherit">
                                        <div class="bt_bb_headline_superheadline_outside"><span class="bt_bb_headline_superheadline">WHAT CAN WE OFFER</span></div>
                                        <h2><span class="bt_bb_headline_content"><span><b>Services</b><br />
                                           <u>We're offering</u></span></span>
                                        </h2>
                                     </header>
                                     <div class="bt_bb_separator bt_bb_bottom_spacing_medium bt_bb_border_style_none"></div>
                                  </div>
                               </div>
                               <div  class="bt_bb_column col-md-6 col-sm-12 bt_bb_align_right bt_bb_vertical_align_bottom bt_bb_animation_fade_in animate bt_bb_padding_normal"  data-width="6">
                                  <div class="bt_bb_column_content">
                                     <div class="bt_bb_button bt_bb_icon_position_right bt_bb_color_scheme_6 bt_bb_style_filled bt_bb_size_normal bt_bb_width_inline bt_bb_shape_slanted_right bt_bb_align_inherit"><a href="<?php echo e(url('/serviecs')); ?>" target="_self" class="bt_bb_link" title="View all Services"><span class="bt_bb_button_text">View all Services</span><span  data-ico-fontawesome="&#xf0a9;" class="bt_bb_icon_holder"></span></a></div>
                                     <div class="bt_bb_separator bt_bb_bottom_spacing_medium bt_bb_border_style_none"></div>
                                  </div>
                               </div>
                            </div>
                         </div>
                         <div class="bt_bb_row_wrapper">
                            <div  class="bt_bb_row bt_bb_column_gap_15" >
                                <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div  class="bt_bb_column col-md-3 col-sm-6 col-ms-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_animation_fade_in zoom_out animate bt_bb_padding_normal"  data-width="3">
                                        <div class="bt_bb_column_content">
                                        <div class="bt_bb_service bt_bb_color_scheme_4 bt_bb_style_filled bt_bb_size_large bt_bb_shape_slanted_right bt_bb_align_inherit bt_bb_highlight_service_true">
                                            <a href="#"  target="_self"  title="Internet Marketing"  data-ico-businessmanagement="<?php echo $data->icon; ?>" class="bt_bb_icon_holder"></a>
                                            <div class="bt_bb_service_content">
                                                <div class="bt_bb_service_content_title"><a href="#" target="_self"><?php echo e($data->title); ?></a></div>
                                            </div>
                                        </div>
                                        <div class="bt_bb_separator bt_bb_bottom_spacing_normal bt_bb_border_style_none bt_bb_hidden_md bt_bb_hidden_lg"></div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                         </div>
                      </div>
                   </div>
                </div>
             </section>
             <section id="bt_bb_section5fb501395ea1e"  data-background_image_src="'http://avantage.bold-themes.com/marketing/wp-content/uploads/sites/4/2019/04/bgn-quote.jpg'" class="bt_bb_section bt_bb_top_spacing_large bt_bb_bottom_spacing_large bt_bb_layout_wide bt_bb_vertical_align_top btLazyLoadBackground bt_bb_background_image bt_bb_hidden_xs bt_bb_hidden_ms bt_bb_hidden_sm" style="background-image:url(http_/avantage.bold-themes.com/marketing/wp-content/plugins/bold-page-builder/img/blank.html);;background-color:#e6aa3f;">
                <div class="bt_bb_port">
                   <div class="bt_bb_cell">
                      <div class="bt_bb_cell_inner">
                         <div class="bt_bb_row_wrapper">
                            <div  class="bt_bb_row bt_bb_column_gap_40" >
                               <div  class="bt_bb_column col-md-6 col-sm-12 bt_bb_align_center bt_bb_vertical_align_top bt_bb_animation_fade_in animate bt_bb_padding_double"  data-width="6">
                                  <div class="bt_bb_column_content">
                                     <div class="bt_bb_separator bt_bb_bottom_spacing_normal bt_bb_border_style_none" style="; border-width: 2px; border-color: transparent; border-style: solid;"></div>
                                     <div class="bt_bb_icon bt_bb_color_scheme_11 bt_bb_style_filled bt_bb_size_normal bt_bb_shape_slanted_right bt_bb_align_inherit"><span  data-ico-fontawesome="&#xf10e;" class="bt_bb_icon_holder"></span></div>
                                     <div class="bt_bb_separator bt_bb_bottom_spacing_medium bt_bb_border_style_none" style="; border-width: 2px; border-color: transparent; border-style: solid;"></div>
                                     <header class="bt_bb_headline bt_bb_color_scheme_5 bt_bb_dash_top bt_bb_size_medium bt_bb_superheadline bt_bb_align_inherit">
                                        <div class="bt_bb_headline_superheadline_outside"><span class="bt_bb_headline_superheadline">STRATEGY CONSULTING + AGENCY SERVICES</span></div>
                                        <h2><span class="bt_bb_headline_content"><span><s><em>From SEO to Online PR, we deliver ROI–driven marketing campaigns that target and convert your key customers.</em></s></span></span></h2>
                                     </header>
                                     <div class="bt_bb_separator bt_bb_top_spacing_medium bt_bb_bottom_spacing_medium bt_bb_border_style_solid" style="; border-width: 2px"></div>
                                     <div class="bt_bb_button bt_bb_icon_position_right bt_bb_color_scheme_11 bt_bb_style_filled bt_bb_size_normal bt_bb_width_inline bt_bb_shape_slanted_right bt_bb_align_inherit"><a href="#" target="_self" class="bt_bb_link" title="Find out More"><span class="bt_bb_button_text">Find out More</span><span  data-ico-fontawesome="&#xf0a9;" class="bt_bb_icon_holder"></span></a></div>
                                     <div class="bt_bb_separator bt_bb_bottom_spacing_normal bt_bb_border_style_none" style="; border-width: 2px; border-color: transparent; border-style: solid;"></div>
                                  </div>
                               </div>
                               <div  class="bt_bb_column col-md-6 col-sm-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_padding_normal"  data-width="6">
                                  <div class="bt_bb_column_content"></div>
                               </div>
                            </div>
                         </div>
                      </div>
                   </div>
                </div>
             </section>
             <section id="bt_bb_section5fb501395fc87"  data-background_image_src="'http://avantage.bold-themes.com/marketing/wp-content/uploads/sites/4/2019/04/bgn-quote.jpg'" class="bt_bb_section bt_bb_top_spacing_medium bt_bb_bottom_spacing_medium bt_bb_layout_wide bt_bb_vertical_align_top btLazyLoadBackground bt_bb_background_image bt_bb_background_overlay_dark_solid bt_bb_hidden_md bt_bb_hidden_lg" style="background-image:url(http_/avantage.bold-themes.com/marketing/wp-content/plugins/bold-page-builder/img/blank.html);;background-color:#e6aa3f;background-position:right top;">
                <div class="bt_bb_port">
                   <div class="bt_bb_cell">
                      <div class="bt_bb_cell_inner">
                         <div class="bt_bb_row_wrapper">
                            <div  class="bt_bb_row" >
                               <div  class="bt_bb_column col-md-12 col-ms-12 bt_bb_align_center bt_bb_vertical_align_top bt_bb_animation_fade_in animate bt_bb_padding_double"  data-width="12">
                                  <div class="bt_bb_column_content">
                                     <div class="bt_bb_icon bt_bb_color_scheme_6 bt_bb_style_filled bt_bb_size_normal bt_bb_shape_slanted_right bt_bb_align_inherit"><span  data-ico-fontawesome="&#xf10e;" class="bt_bb_icon_holder"></span></div>
                                     <div class="bt_bb_separator bt_bb_bottom_spacing_medium bt_bb_border_style_none" style="; border-width: 2px; border-color: transparent; border-style: solid;"></div>
                                     <header class="bt_bb_headline bt_bb_color_scheme_1 bt_bb_dash_top bt_bb_size_medium bt_bb_superheadline bt_bb_align_inherit">
                                        <div class="bt_bb_headline_superheadline_outside"><span class="bt_bb_headline_superheadline">STRATEGY CONSULTING + AGENCY SERVICES</span></div>
                                        <h2><span class="bt_bb_headline_content"><span><s><em>From SEO to Online PR, we deliver ROI–driven marketing campaigns that target and convert your key customers.</em></s></span></span></h2>
                                     </header>
                                     <div class="bt_bb_separator bt_bb_top_spacing_medium bt_bb_bottom_spacing_medium bt_bb_border_style_solid" style="; border-width: 2px"></div>
                                     <div class="bt_bb_button bt_bb_icon_position_right bt_bb_color_scheme_6 bt_bb_style_filled bt_bb_size_normal bt_bb_width_inline bt_bb_shape_slanted_right bt_bb_align_inherit"><a href="#" target="_self" class="bt_bb_link" title="Find out More"><span class="bt_bb_button_text">Find out More</span><span  data-ico-fontawesome="&#xf0a9;" class="bt_bb_icon_holder"></span></a></div>
                                  </div>
                               </div>
                            </div>
                         </div>
                      </div>
                   </div>
                </div>
             </section>
             
             <section id="bt_bb_section5fb5013964947"  class="bt_bb_section bt_bb_top_spacing_large bt_bb_layout_boxed_1200 bt_bb_vertical_align_top" >
                <div class="bt_bb_port">
                   <div class="bt_bb_cell">
                      <div class="bt_bb_cell_inner">
                         <div class="bt_bb_row_wrapper">
                            <div  class="bt_bb_row" >
                               <div  class="bt_bb_column col-md-6 col-sm-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_animation_fade_in animate bt_bb_padding_normal"  data-width="6">
                                  <div class="bt_bb_column_content">
                                     <header class="bt_bb_headline bt_bb_dash_top bt_bb_size_large bt_bb_superheadline bt_bb_align_inherit">
                                        <div class="bt_bb_headline_superheadline_outside"><span class="bt_bb_headline_superheadline">WHAT CAN WE OFFER</span></div>
                                        <h2><span class="bt_bb_headline_content"><span><b>Avantage</b><br />
                                           <u>Packages & Pricing</u></span></span>
                                        </h2>
                                     </header>
                                     <div class="bt_bb_separator bt_bb_bottom_spacing_medium bt_bb_border_style_none"></div>
                                  </div>
                               </div>
                               <div  class="bt_bb_column col-md-6 col-sm-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_padding_normal"  data-width="6">
                                  <div class="bt_bb_column_content"></div>
                               </div>
                            </div>
                         </div>
                         <div class="bt_bb_row_wrapper">
                            <div  class="bt_bb_row bt_bb_column_gap_10" >
                               <div  class="bt_bb_column col-md-4 col-ms-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_animation_fade_in zoom_out animate bt_bb_padding_normal"  data-width="4">
                                  <div class="bt_bb_column_content">
                                     <div class="bt_bb_separator bt_bb_top_spacing_normal bt_bb_bottom_spacing_normal bt_bb_border_style_none"></div>
                                     <div class="bt_bb_price_list bt_bb_color_scheme_5" style=";background-color:#f1f1f1;">
                                        <div class="bt_bb_icon bt_bb_style_filled bt_bb_size_large bt_bb_shape_slanted_right bt_bb_vertical_position_half_above"><span  data-ico-businessandfinance="&#xe914;" class="bt_bb_icon_holder"></span></div>
                                        <div class="bt_bb_price_list_title_subtitle_price">
                                           <div class="bt_bb_price_list_title_wrap">
                                              <div class="bt_bb_price_list_price"><span class="bt_bb_price_list_currency">$</span><span class="bt_bb_price_list_amount">146</span></div>
                                              <div class="bt_bb_price_list_title_subtitle">
                                                 <div class="bt_bb_price_list_subtitle">STARTER PACKAGE</div>
                                                 <div class="bt_bb_price_list_title">Website Optimization</div>
                                              </div>
                                           </div>
                                        </div>
                                        <ul>
                                           <li>Basic website checkup</li>
                                           <li>SEO recommendations</li>
                                           <li>Google Ads recommendations</li>
                                           <li>W3C Validator recommendations</li>
                                        </ul>
                                     </div>
                                     <div class="bt_bb_separator bt_bb_top_spacing_extra_small bt_bb_bottom_spacing_small bt_bb_border_style_none"></div>
                                     <div class="bt_bb_button bt_bb_icon_position_right bt_bb_color_scheme_6 bt_bb_style_filled bt_bb_size_normal bt_bb_width_inline bt_bb_shape_inherit bt_bb_align_right" style="margin-right: 1.875em"><a href="#" target="_self" class="bt_bb_link" title="Buy now"><span class="bt_bb_button_text">Buy now</span><span  data-ico-fontawesome="&#xf0a9;" class="bt_bb_icon_holder"></span></a></div>
                                     <div class="bt_bb_separator bt_bb_bottom_spacing_small bt_bb_border_style_none"></div>
                                  </div>
                               </div>
                               <div  class="bt_bb_column col-md-4 col-ms-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_animation_fade_in zoom_out animate bt_bb_padding_normal"  data-width="4">
                                  <div class="bt_bb_column_content">
                                     <div class="bt_bb_separator bt_bb_top_spacing_normal bt_bb_bottom_spacing_normal bt_bb_border_style_none"></div>
                                     <div class="bt_bb_price_list bt_bb_color_scheme_11" style=";background-color:#e49f37;">
                                        <div class="bt_bb_icon bt_bb_style_filled bt_bb_size_large bt_bb_shape_slanted_right bt_bb_vertical_position_half_above"><span  data-ico-businessandfinance="&#xe917;" class="bt_bb_icon_holder"></span></div>
                                        <div class="bt_bb_price_list_title_subtitle_price">
                                           <div class="bt_bb_price_list_title_wrap">
                                              <div class="bt_bb_price_list_price"><span class="bt_bb_price_list_currency">$</span><span class="bt_bb_price_list_amount">199</span></div>
                                              <div class="bt_bb_price_list_title_subtitle">
                                                 <div class="bt_bb_price_list_subtitle">UPGRADED PACKAGE</div>
                                                 <div class="bt_bb_price_list_title">Marketing &amp; Optimization</div>
                                              </div>
                                           </div>
                                        </div>
                                        <ul>
                                           <li>Website checkup (W3C included)</li>
                                           <li>SEO changes</li>
                                           <li>Google Ads basic plan</li>
                                           <li>Social Media plan</li>
                                        </ul>
                                     </div>
                                     <div class="bt_bb_separator bt_bb_top_spacing_extra_small bt_bb_bottom_spacing_small bt_bb_border_style_none"></div>
                                     <div class="bt_bb_button bt_bb_icon_position_right bt_bb_color_scheme_11 bt_bb_style_filled bt_bb_size_normal bt_bb_width_inline bt_bb_shape_inherit bt_bb_align_right" style="margin-right: 1.875em"><a href="#" target="_self" class="bt_bb_link" title="Buy now"><span class="bt_bb_button_text">Buy now</span><span  data-ico-fontawesome="&#xf0a9;" class="bt_bb_icon_holder"></span></a></div>
                                     <div class="bt_bb_separator bt_bb_bottom_spacing_small bt_bb_border_style_none"></div>
                                  </div>
                               </div>
                               <div  class="bt_bb_column col-md-4 col-ms-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_animation_fade_in zoom_out animate bt_bb_padding_normal"  data-width="4">
                                  <div class="bt_bb_column_content">
                                     <div class="bt_bb_separator bt_bb_top_spacing_normal bt_bb_bottom_spacing_normal bt_bb_border_style_none"></div>
                                     <div class="bt_bb_price_list bt_bb_color_scheme_5" style=";background-color:#f1f1f1;">
                                        <div class="bt_bb_icon bt_bb_style_filled bt_bb_size_large bt_bb_shape_slanted_right bt_bb_vertical_position_half_above"><span  data-ico-businessandfinance="&#xe918;" class="bt_bb_icon_holder"></span></div>
                                        <div class="bt_bb_price_list_title_subtitle_price">
                                           <div class="bt_bb_price_list_title_wrap">
                                              <div class="bt_bb_price_list_price"><span class="bt_bb_price_list_currency">$</span><span class="bt_bb_price_list_amount">299</span></div>
                                              <div class="bt_bb_price_list_title_subtitle">
                                                 <div class="bt_bb_price_list_subtitle">FULL PACKAGE</div>
                                                 <div class="bt_bb_price_list_title">Complete Website Strategy</div>
                                              </div>
                                           </div>
                                        </div>
                                        <ul>
                                           <li>Website checkup (W3C included)</li>
                                           <li>SEO changes</li>
                                           <li>Google Ads marketing plan</li>
                                           <li>Social Media marketing plan</li>
                                        </ul>
                                     </div>
                                     <div class="bt_bb_separator bt_bb_top_spacing_extra_small bt_bb_bottom_spacing_small bt_bb_border_style_none"></div>
                                     <div class="bt_bb_button bt_bb_icon_position_right bt_bb_color_scheme_6 bt_bb_style_filled bt_bb_size_normal bt_bb_width_inline bt_bb_shape_inherit bt_bb_align_right" style="margin-right: 1.875em"><a href="#" target="_self" class="bt_bb_link" title="Buy now"><span class="bt_bb_button_text">Buy now</span><span  data-ico-fontawesome="&#xf0a9;" class="bt_bb_icon_holder"></span></a></div>
                                     <div class="bt_bb_separator bt_bb_bottom_spacing_small bt_bb_border_style_none"></div>
                                  </div>
                               </div>
                            </div>
                         </div>
                      </div>
                   </div>
                </div>
             </section>
             <section id="bt_bb_section5fb50139661c3"  data-background_image_src="'http://avantage.bold-themes.com/marketing/wp-content/uploads/sites/4/2019/04/bgn-passion.jpg'" class="bt_bb_section bt_bb_top_spacing_large bt_bb_layout_boxed_1200 bt_bb_vertical_align_top btLazyLoadBackground bt_bb_background_image bt_bb_section_show_right_boxed_content" style="background-image:url(http_/avantage.bold-themes.com/marketing/wp-content/plugins/bold-page-builder/img/blank.html);background-position:center bottom;background-size:cover;">
                <div class="bt_bb_port">
                   <div class="bt_bb_cell">
                      <div class="bt_bb_cell_inner">
                         <div class="bt_bb_row_wrapper">
                            <div  class="bt_bb_row" >
                               <div  class="bt_bb_column col-md-6 col-sm-12 bt_bb_align_right bt_bb_vertical_align_bottom bt_bb_animation_fade_in zoom_out animate bt_bb_padding_normal"  data-width="6">
                                  <div class="bt_bb_column_content">
                                     <div class="bt_bb_image bt_bb_shape_square bt_bb_align_inherit bt_bb_hover_style_simple bt_bb_content_display_always bt_bb_content_align_middle bt_bb_hidden_xs bt_bb_hidden_ms bt_bb_hidden_sm"><span><img src="<?php echo e(url('assets/web/assests/wp-content/uploads/sites/4/2019/04/img-passion-768x840.png')); ?>" data-full_image_src="http://avantage.bold-themes.com/marketing/wp-content/uploads/sites/4/2019/04/img-passion.png"  title="img-passion" alt="http://avantage.bold-themes.com/marketing/wp-content/uploads/sites/4/2019/04/img-passion-768x840.png"></span></div>
                                  </div>
                               </div>
                               <div  class="bt_bb_column col-md-6 col-sm-12 bt_bb_align_left bt_bb_vertical_align_bottom bt_bb_animation_fade_in animate bt_bb_padding_normal"  data-width="6">
                                  <div class="bt_bb_column_content">
                                     <header class="bt_bb_headline bt_bb_dash_top bt_bb_size_large bt_bb_superheadline bt_bb_subheadline bt_bb_align_inherit">
                                        <div class="bt_bb_headline_superheadline_outside"><span class="bt_bb_headline_superheadline">TOTALLY COMMITED</span></div>
                                        <h2><span class="bt_bb_headline_content"><span><b>Digital Marketing</b><br />
                                           <u>Is Our Passion</u></span></span>
                                        </h2>
                                        <div class="bt_bb_headline_subheadline">78% of CEO’s believe marketers don’t focus on ROI, we do. Our priorities have always remained the same: to help companies maximize their marketing ROI, accelerate customer growth, and gain a lasting competitive edge in their industries.</div>
                                     </header>
                                     <div class="bt_bb_separator bt_bb_top_spacing_small bt_bb_bottom_spacing_normal bt_bb_border_style_none"></div>
                                     <div  class="bt_bb_row_inner bt_bb_column_inner_gap_10" >
                                        <div  class="bt_bb_column_inner col-md-4 col-ms-12 bt_bb_align_center bt_bb_vertical_align_top bt_bb_padding_double"  data-width="4">
                                           <div class="bt_bb_column_inner_content">
                                              <div class="bt_bb_icon bt_bb_color_scheme_3 bt_bb_style_borderless bt_bb_size_xlarge bt_bb_shape_circle bt_bb_align_inherit"><span  data-ico-businessandfinance="&#xe90e;" class="bt_bb_icon_holder"></span></div>
                                              <div class="bt_bb_separator bt_bb_bottom_spacing_normal bt_bb_border_style_none"></div>
                                              <div class="bt_bb_counter_holder bt_bb_size_large"><span class="bt_bb_counter animate" data-digit-length="4"><span class="onedigit p4 d5" data-digit="5"><span class="n0">0</span><span class="n1">1</span><span class="n2">2</span><span class="n3">3</span><span class="n4">4</span><span class="n5">5</span><span class="n6">6</span><span class="n7">7</span><span class="n8">8</span><span class="n9">9</span><span class="n0">0</span></span><span class="onedigit p3 d0" data-digit="0"><span class="n0">0</span><span class="n1">1</span><span class="n2">2</span><span class="n3">3</span><span class="n4">4</span><span class="n5">5</span><span class="n6">6</span><span class="n7">7</span><span class="n8">8</span><span class="n9">9</span><span class="n0">0</span></span><span class="onedigit p2 d0" data-digit="0"><span class="n0">0</span><span class="n1">1</span><span class="n2">2</span><span class="n3">3</span><span class="n4">4</span><span class="n5">5</span><span class="n6">6</span><span class="n7">7</span><span class="n8">8</span><span class="n9">9</span><span class="n0">0</span></span><span class="onedigit p1 d+" data-digit="+"><span class="t">+</span></span></span></div>
                                              <div class="bt_bb_separator bt_bb_bottom_spacing_extra_small bt_bb_border_style_none"></div>
                                              <div  class="bt_bb_text" >
                                                 <p style="font-size: .875em;">Business advices given over 30 years</p>
                                              </div>
                                              <div class="bt_bb_separator bt_bb_bottom_spacing_normal bt_bb_border_style_none bt_bb_hidden_md bt_bb_hidden_lg"></div>
                                           </div>
                                        </div>
                                        <div  class="bt_bb_column_inner col-md-4 col-ms-12 bt_bb_align_center bt_bb_vertical_align_top bt_bb_padding_double"  data-width="4">
                                           <div class="bt_bb_column_inner_content">
                                              <div class="bt_bb_icon bt_bb_color_scheme_3 bt_bb_style_borderless bt_bb_size_xlarge bt_bb_shape_circle bt_bb_align_inherit"><span  data-ico-businessandfinance="&#xe904;" class="bt_bb_icon_holder"></span></div>
                                              <div class="bt_bb_separator bt_bb_bottom_spacing_normal bt_bb_border_style_none"></div>
                                              <div class="bt_bb_counter_holder bt_bb_size_large"><span class="bt_bb_counter animate" data-digit-length="4"><span class="onedigit p4 d1" data-digit="1"><span class="n0">0</span><span class="n1">1</span><span class="n2">2</span><span class="n3">3</span><span class="n4">4</span><span class="n5">5</span><span class="n6">6</span><span class="n7">7</span><span class="n8">8</span><span class="n9">9</span><span class="n0">0</span></span><span class="onedigit p3 d7" data-digit="7"><span class="n0">0</span><span class="n1">1</span><span class="n2">2</span><span class="n3">3</span><span class="n4">4</span><span class="n5">5</span><span class="n6">6</span><span class="n7">7</span><span class="n8">8</span><span class="n9">9</span><span class="n0">0</span></span><span class="onedigit p2 d0" data-digit="0"><span class="n0">0</span><span class="n1">1</span><span class="n2">2</span><span class="n3">3</span><span class="n4">4</span><span class="n5">5</span><span class="n6">6</span><span class="n7">7</span><span class="n8">8</span><span class="n9">9</span><span class="n0">0</span></span><span class="onedigit p1 d+" data-digit="+"><span class="t">+</span></span></span></div>
                                              <div class="bt_bb_separator bt_bb_bottom_spacing_extra_small bt_bb_border_style_none"></div>
                                              <div  class="bt_bb_text" >
                                                 <p style="font-size: .875em;">Businesses guided over thirty years</p>
                                              </div>
                                              <div class="bt_bb_separator bt_bb_bottom_spacing_normal bt_bb_border_style_none bt_bb_hidden_md bt_bb_hidden_lg"></div>
                                           </div>
                                        </div>
                                        <div  class="bt_bb_column_inner col-md-4 col-ms-12 bt_bb_align_center bt_bb_vertical_align_top bt_bb_padding_double"  data-width="4">
                                           <div class="bt_bb_column_inner_content">
                                              <div class="bt_bb_icon bt_bb_color_scheme_3 bt_bb_style_borderless bt_bb_size_xlarge bt_bb_shape_circle bt_bb_align_inherit"><span  data-ico-businessandfinance="&#xe918;" class="bt_bb_icon_holder"></span></div>
                                              <div class="bt_bb_separator bt_bb_bottom_spacing_normal bt_bb_border_style_none"></div>
                                              <div class="bt_bb_counter_holder bt_bb_size_large"><span class="bt_bb_counter animate" data-digit-length="3"><span class="onedigit p3 d3" data-digit="3"><span class="n0">0</span><span class="n1">1</span><span class="n2">2</span><span class="n3">3</span><span class="n4">4</span><span class="n5">5</span><span class="n6">6</span><span class="n7">7</span><span class="n8">8</span><span class="n9">9</span><span class="n0">0</span></span><span class="onedigit p2 d0" data-digit="0"><span class="n0">0</span><span class="n1">1</span><span class="n2">2</span><span class="n3">3</span><span class="n4">4</span><span class="n5">5</span><span class="n6">6</span><span class="n7">7</span><span class="n8">8</span><span class="n9">9</span><span class="n0">0</span></span><span class="onedigit p1 d+" data-digit="+"><span class="t">+</span></span></span></div>
                                              <div class="bt_bb_separator bt_bb_bottom_spacing_extra_small bt_bb_border_style_none"></div>
                                              <div  class="bt_bb_text" >
                                                 <p style="font-size: .875em;">Business Excellence awards achieved</p>
                                              </div>
                                           </div>
                                        </div>
                                     </div>
                                     <div class="bt_bb_separator bt_bb_bottom_spacing_large bt_bb_border_style_none bt_bb_hidden_xs bt_bb_hidden_ms bt_bb_hidden_sm"></div>
                                     <div class="bt_bb_separator bt_bb_bottom_spacing_medium bt_bb_border_style_none bt_bb_hidden_md bt_bb_hidden_lg"></div>
                                     <div class="bt_bb_image bt_bb_shape_square bt_bb_align_inherit bt_bb_hover_style_simple bt_bb_content_display_always bt_bb_content_align_middle bt_bb_hidden_md bt_bb_hidden_lg"><span><img src = "wp-content/plugins/bold-page-builder/img/blank.gif" data-full_image_src="http://avantage.bold-themes.com/marketing/wp-content/uploads/sites/4/2019/04/img-passion.png" data-image_src="http://avantage.bold-themes.com/marketing/wp-content/uploads/sites/4/2019/04/img-passion-768x840.png" title="img-passion" alt="http://avantage.bold-themes.com/marketing/wp-content/uploads/sites/4/2019/04/img-passion-768x840.png" class="btLazyLoadImage"></span></div>
                                  </div>
                               </div>
                            </div>
                         </div>
                      </div>
                   </div>
                </div>
             </section>
             <section id="bt_bb_section5fb50139688c9"  class="bt_bb_section bt_bb_bottom_spacing_large bt_bb_layout_boxed_1200 bt_bb_vertical_align_top" style="margin-top: -2.5em;">
                <div class="bt_bb_port">
                   <div class="bt_bb_cell">
                      <div class="bt_bb_cell_inner">
                         <div class="bt_bb_row_wrapper">
                            <div  class="bt_bb_row bt_bb_column_gap_10" >
                                <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div  class="bt_bb_column col-md-4 col-ms-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_animation_fade_in animate bt_bb_padding_text_indent" style="margin-bottom: 20px;" data-width="4">
                                        <div class="bt_bb_column_content" style="background-color:rgba(241, 241, 241, 1);">
                                        <div class="bt_bb_image bt_bb_shape_square bt_bb_align_inherit bt_bb_hover_style_zoom-in bt_bb_content_display_show-on-hover bt_bb_content_align_bottom bt_bb_content_exists">
                                            <span><img src = "" data-full_image_src="http://avantage.bold-themes.com/marketing/wp-content/uploads/sites/4/2019/04/img-people-01.jpg" data-image_src="http://avantage.bold-themes.com/marketing/wp-content/uploads/sites/4/2019/04/img-people-01.jpg" title="Mark Richardson" alt="http://avantage.bold-themes.com/marketing/wp-content/uploads/sites/4/2019/04/img-people-01.jpg" class="btLazyLoadImage"></span>
                                            <div class="bt_bb_image_content" style="background-color: rgba(228, 159, 55, 0.8);">
                                                <div class="bt_bb_image_content_flex">
                                                    <div class="bt_bb_image_content_inner">
                                                    <div class="bt_bb_button bt_bb_icon_position_left bt_bb_color_scheme_8 bt_bb_style_filled bt_bb_size_small bt_bb_width_inline bt_bb_shape_inherit bt_bb_align_inherit"><a href="#" target="_self" class="bt_bb_link" title="View profile"><span class="bt_bb_button_text">View profile</span></a></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="bt_bb_separator bt_bb_border_style_none"></div>
                                        <div class="bt_bb_separator bt_bb_bottom_spacing_normal bt_bb_border_style_none"></div>
                                        <header class="bt_bb_headline bt_bb_dash_top bt_bb_size_normal bt_bb_superheadline bt_bb_subheadline bt_bb_align_inherit">
                                            <div class="bt_bb_headline_superheadline_outside"><span class="bt_bb_headline_superheadline"><?php echo e($data->designation); ?></span></div>
                                            <h3><span class="bt_bb_headline_content"><span></span><?php echo e($data->name); ?></span></h3>
                                            <div class="bt_bb_headline_subheadline"></div>
                                        </header>
                                        
                                        </div>
                                    </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                         </div>
                      </div>
                   </div>
                </div>
             </section>
             <section id="bt_bb_section5fb501396cc2a"  data-background_image_src="'http://avantage.bold-themes.com/marketing/wp-content/uploads/sites/4/2019/04/bgn-get-a-quote.jpg'" class="bt_bb_section bt_bb_top_spacing_large bt_bb_bottom_spacing_large bt_bb_layout_boxed_1200 bt_bb_vertical_align_top btLazyLoadBackground bt_bb_background_image" style="background-image:url(http_/avantage.bold-themes.com/marketing/wp-content/plugins/bold-page-builder/img/blank.html);;background-color:#eaedee;">
                <div class="bt_bb_port">
                   <div class="bt_bb_cell">
                      <div class="bt_bb_cell_inner">
                         <div class="bt_bb_row_wrapper">
                            <div  class="bt_bb_row" >
                               <div  class="bt_bb_column col-md-6 col-sm-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_padding_normal"  data-width="6">
                                  <div class="bt_bb_column_content"></div>
                               </div>
                               <div  class="bt_bb_column col-md-6 col-sm-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_animation_fade_in animate bt_bb_padding_normal"  data-width="6">
                                  <div class="bt_bb_column_content">
                                     <header class="bt_bb_headline bt_bb_dash_top bt_bb_size_medium bt_bb_superheadline bt_bb_subheadline bt_bb_align_inherit">
                                        <div class="bt_bb_headline_superheadline_outside"><span class="bt_bb_headline_superheadline">FOCUS ON WHAT'S IMPORTANT</span></div>
                                        <h3><span class="bt_bb_headline_content"><span><b>Let's talk about improving</b><br />
                                           <u>your business marketing...</u></span></span>
                                        </h3>
                                        <div class="bt_bb_headline_subheadline">Our priorities have always remained the same: to help companies maximize their marketing ROI, accelerate customer growth, and gain a lasting competitive edge in their industries. Our background in financial mathematics and digital marketing, give us an analytical and quantitative approach to do just that.</div>
                                     </header>
                                     <!-- <div class="bt_bb_separator bt_bb_top_spacing_normal bt_bb_border_style_none"></div>
                                     <div  class="bt_bb_text" >
                                        <div role="form" class="wpcf7" id="wpcf7-f4-p106-o1" lang="en-US" dir="ltr">
                                           <div class="screen-reader-response" aria-live="polite"></div>
                                           <form action="http://avantage.bold-themes.com/marketing/#wpcf7-f4-p106-o1" method="post" class="wpcf7-form" novalidate="novalidate">
                                              <div style="display: none;">
                                                 <input type="hidden" name="_wpcf7" value="4" />
                                                 <input type="hidden" name="_wpcf7_version" value="5.1.9" />
                                                 <input type="hidden" name="_wpcf7_locale" value="en_US" />
                                                 <input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f4-p106-o1" />
                                                 <input type="hidden" name="_wpcf7_container_post" value="106" />
                                              </div>
                                              <p><label> Your Name (required)<br />
                                                 <span class="wpcf7-form-control-wrap your-name"><input type="text" name="your-name" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" /></span> </label>
                                              </p>
                                              <p><label> Your Email (required)<br />
                                                 <span class="wpcf7-form-control-wrap your-email"><input type="email" name="your-email" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email" aria-required="true" aria-invalid="false" /></span> </label>
                                              </p>
                                              <p><label> Subject<br />
                                                 <span class="wpcf7-form-control-wrap your-subject"><input type="text" name="your-subject" value="" size="40" class="wpcf7-form-control wpcf7-text" aria-invalid="false" /></span> </label>
                                              </p>
                                              <p><label> Your Message<br />
                                                 <span class="wpcf7-form-control-wrap your-message"><textarea name="your-message" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea" aria-invalid="false"></textarea></span> </label>
                                              </p>
                                              <p><input type="submit" value="Send" class="wpcf7-form-control wpcf7-submit" /></p>
                                              <div class="wpcf7-response-output wpcf7-display-none" aria-hidden="true"></div>
                                           </form>
                                        </div>
                                     </div> -->
                                  </div>
                               </div>
                            </div>
                         </div>
                      </div>
                   </div>
                </div>
             </section>
             
          </div>
       </div>
       <!-- /boldthemes_content -->
    </div>
    <!-- /contentHolder -->
 </div>



<?php echo $__env->make('Web.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH C:\xampp\htdocs\technow\resources\views/Web/home.blade.php ENDPATH**/ ?>