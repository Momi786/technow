<!-- /contentWrap -->
<div class="btSiteFooter">
    <div class="bt_bb_wrapper">
       <section id="bt_bb_section5fb501398bb0e"  class="bt_bb_section bt_bb_top_spacing_medium bt_bb_color_scheme_1 bt_bb_layout_boxed_1200 bt_bb_vertical_align_top" style="background: linear-gradient(to right, #ebb745 0%, #dd8729 100%);">
          <div class="bt_bb_port">
             <div class="bt_bb_cell">
                <div class="bt_bb_cell_inner">
                   <div class="bt_bb_row_wrapper">
                      <div  class="bt_bb_row bt_bb_column_gap_10 bt_bb_hidden_xs bt_bb_hidden_ms" >
                         <div  class="bt_bb_column col-md-3 col-sm-6 col-ms-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_padding_normal"  data-width="3">
                            <div class="bt_bb_column_content">
                               <header class="bt_bb_headline bt_bb_color_scheme_6 bt_bb_dash_top bt_bb_size_extrasmall bt_bb_superheadline bt_bb_subheadline bt_bb_align_inherit">
                                  <h5><span class="bt_bb_headline_superheadline">TECHNOW</span><span class="bt_bb_headline_content"><span><u>Headquarters</u></span></span></h5>
                                  <div class="bt_bb_headline_subheadline">Organically grow the holistic world view of disruptive innovation via empowerment.</div>
                               </header>
                               <div class="bt_bb_separator bt_bb_bottom_spacing_small bt_bb_border_style_none"></div>
                               <div class="bt_bb_icon bt_bb_color_scheme_1 bt_bb_style_borderless bt_bb_size_xsmall bt_bb_shape_circle bt_bb_align_inherit"><a href="tel:+92 345 66770000"  target="_self"  title="+92 345 66770000"  data-ico-fontawesome="&#xf095;" class="bt_bb_icon_holder"><span>+92 345 66770000</span></a></div>
                               <div class="bt_bb_separator bt_bb_bottom_spacing_extra_small bt_bb_border_style_none"></div>
                               <div class="bt_bb_icon bt_bb_color_scheme_1 bt_bb_style_borderless bt_bb_size_xsmall bt_bb_shape_circle bt_bb_align_inherit"><a href="mailto:info@technow.pk"  target="_self"  title="info@technow.pk"  data-ico-fontawesome="&#xf0e0;" class="bt_bb_icon_holder"><span>info@technow.pk</span></a></div>
                               <div class="bt_bb_separator bt_bb_bottom_spacing_extra_small bt_bb_border_style_none"></div>
                               <div class="bt_bb_icon bt_bb_color_scheme_1 bt_bb_style_borderless bt_bb_size_xsmall bt_bb_shape_circle bt_bb_align_inherit"><a href="http://www.forexustaad.com"  target="_blank"  title="avantage.co.uk"  data-ico-fontawesome="&#xf0ac;" class="bt_bb_icon_holder"><span>Technow Pakistan</span></a></div>
                               <div class="bt_bb_separator bt_bb_border_style_none"></div>
                               <div class="bt_bb_separator bt_bb_top_spacing_normal bt_bb_bottom_spacing_medium bt_bb_border_style_none"></div>
                            </div>
                         </div>
                         <div  class="bt_bb_column col-md-3 col-sm-6 col-ms-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_padding_normal"  data-width="3">
                            <div class="bt_bb_column_content">
                               <header class="bt_bb_headline bt_bb_color_scheme_6 bt_bb_dash_top bt_bb_size_extrasmall bt_bb_superheadline bt_bb_align_inherit">
                                  <h5><span class="bt_bb_headline_superheadline">OUR LOCATIONS</span><span class="bt_bb_headline_content"><span><u>Where to find us?</u></span></span></h5>
                               </header>
                               <div class="bt_bb_separator bt_bb_bottom_spacing_small bt_bb_border_style_none"></div>
                               <div class="bt_bb_image bt_bb_shape_square bt_bb_align_inherit bt_bb_hover_style_simple bt_bb_content_display_always bt_bb_content_align_middle"><span><img src = "<?php echo e(url('assets/web/assests/wp-content/uploads/sites/4/2019/04/img-footer-map.png')); ?> "class="btLazyLoadImage"></span></div>
                               <div class="bt_bb_separator bt_bb_border_style_none"></div>
                               <div class="bt_bb_separator bt_bb_top_spacing_normal bt_bb_bottom_spacing_medium bt_bb_border_style_none"></div>
                            </div>
                         </div>
                         <div  class="bt_bb_column col-md-3 col-sm-6 col-ms-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_padding_normal"  data-width="3">
                            <div class="bt_bb_column_content">
                               <div class="bt_bb_separator bt_bb_top_spacing_medium bt_bb_bottom_spacing_medium bt_bb_border_style_none"></div>
                               <div class="bt_bb_icon bt_bb_color_scheme_8 bt_bb_style_borderless bt_bb_size_xsmall bt_bb_shape_circle bt_bb_align_inherit"><a href="tel:+92 345 66770000"  target="_self"  title="London: 020 7946 0020"  data-ico-fontawesome="&#xf041;" class="bt_bb_icon_holder"><span>Gujranwala: +92 345 66770000</span></a></div>

                            </div>
                         </div>
                         <div  class="bt_bb_column col-md-3 col-sm-6 col-ms-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_padding_normal"  data-width="3">
                            <div class="bt_bb_column_content">
                               <header class="bt_bb_headline bt_bb_color_scheme_6 bt_bb_dash_top bt_bb_size_extrasmall bt_bb_superheadline bt_bb_subheadline bt_bb_align_inherit">
                                  <h5><span class="bt_bb_headline_superheadline">GET IN TOUCH</span><span class="bt_bb_headline_content"><span><u>Technow Social links</u></span></span></h5>
                                  <div class="bt_bb_headline_subheadline">Taking seamless key performance indicators offline to maximise the long tail.</div>
                               </header>
                               <div class="bt_bb_separator bt_bb_top_spacing_small bt_bb_border_style_none"></div>
                               <div class="bt_bb_icon bt_bb_color_scheme_2 bt_bb_style_filled bt_bb_size_small bt_bb_shape_circle bt_bb_align_inherit" style="min-width: 3em"><a href="https://www.facebook.com/Technow.pk/"  target="_blank"   data-ico-fontawesome="&#xf09a;" class="bt_bb_icon_holder"></a></div>
                               <div class="bt_bb_icon bt_bb_color_scheme_2 bt_bb_style_filled bt_bb_size_small bt_bb_shape_circle bt_bb_align_inherit" style="min-width: 3em"><a href="https://www.facebook.com/Technow.pk/"  target="_blank"   data-ico-fontawesome="&#xf099;" class="bt_bb_icon_holder"></a></div>
                               <div class="bt_bb_icon bt_bb_color_scheme_2 bt_bb_style_filled bt_bb_size_small bt_bb_shape_circle bt_bb_align_inherit" style="min-width: 3em"><a href="https://www.facebook.com/Technow.pk/"  target="_blank"   data-ico-fontawesome="&#xf231;" class="bt_bb_icon_holder"></a></div>
                               <div class="bt_bb_icon bt_bb_color_scheme_2 bt_bb_style_filled bt_bb_size_small bt_bb_shape_circle bt_bb_align_inherit" style="min-width: 3em"><a href="https://www.facebook.com/Technow.pk/"  target="_blank"   data-ico-fontawesome="&#xf0e1;" class="bt_bb_icon_holder"></a></div>
                               <div class="bt_bb_separator bt_bb_border_style_none"></div>
                               <div class="bt_bb_separator bt_bb_top_spacing_normal bt_bb_bottom_spacing_medium bt_bb_border_style_none"></div>
                            </div>


</div>
</div>
</div>
                </div>
                </div>
                </div>
                </section>
                <section id="bt_bb_section5fb501c193fd4"  class="bt_bb_section bt_bb_color_scheme_1 bt_bb_layout_boxed_1200 bt_bb_vertical_align_top" style=";background-color:#26272a;">
                 <div class="bt_bb_port">
                    <div class="bt_bb_cell">
                       <div class="bt_bb_cell_inner">
                          <div class="bt_bb_row_wrapper">
                             <div  class="bt_bb_row" >
                                <div  class="bt_bb_column col-md-12 col-ms-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_padding_normal"  data-width="12">
                                   <div class="bt_bb_column_content">
                                      <div class="bt_bb_separator bt_bb_top_spacing_normal bt_bb_border_style_none"></div>
                                   </div>
                                </div>
                             </div>
                          </div>
                          <div class="bt_bb_row_wrapper">
                             <div  class="bt_bb_row bt_bb_hidden_xs bt_bb_hidden_ms" >
                                <div  class="bt_bb_column col-md-4 col-ms-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_padding_normal"  data-width="4">
                                   <div class="bt_bb_column_content">
                                      <div  class="bt_bb_text" >
                                         <p>Copyright by <strong>Technow Pakistan</strong>. All rights reserved.</p>
                                      </div>
                                   </div>
                                </div>

                             </div>
                          </div>
                          <div class="bt_bb_row_wrapper">
                             <div  class="bt_bb_row bt_bb_hidden_sm bt_bb_hidden_md bt_bb_hidden_lg" >
                                <div  class="bt_bb_column col-md-12 col-ms-12 bt_bb_align_center bt_bb_vertical_align_top bt_bb_padding_normal"  data-width="12">
                                   <div class="bt_bb_column_content">
                                      <div  class="bt_bb_text" >
                                         <p class=""></p>Copyright by <strong>Technow Pakistan</strong>. All rights reserved.</p>
                                      </div>
                                      <div class="bt_bb_separator bt_bb_top_spacing_normal bt_bb_border_style_none"></div>

                                   </div>
                                </div>
                             </div>
                          </div>
                          <div class="bt_bb_row_wrapper">
                             <div  class="bt_bb_row" >
                                <div  class="bt_bb_column col-md-12 col-ms-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_padding_normal"  data-width="12">
                                   <div class="bt_bb_column_content">
                                      <div class="bt_bb_separator bt_bb_top_spacing_normal bt_bb_border_style_none"></div>
                                   </div>
                                </div>
                             </div>
                          </div>
                       </div>
                    </div>
                 </div>
              </section>
                </div>
                </div>
</div>






<!-- /scripts -->

<script type='text/javascript' src='<?php echo e(url('assets/web/assests/wp-includes/js/jquery/jquery4a5f.js?ver=1.12.4-wp')); ?>' id='jquery-core-js'></script>
<script type='text/javascript' src='<?php echo e(url('assets/web/assests/wp-content/plugins/bold-page-builder/slick/slick.min5697.js?ver=5.5.3')); ?>' id='bt_bb_slick-js'></script>
<script type='text/javascript' src='<?php echo e(url('assets/web/assests/wp-content/plugins/bold-page-builder/content_elements_misc/js/jquery.magnific-popup.min5697.js?ver=5.5.3')); ?>' id='bt_bb_magnific-js'></script>
<script type='text/javascript' src='<?php echo e(url('assets/web/assests/wp-content/plugins/bold-page-builder/content_elements_misc/js/content_elements5697.js?ver=5.5.3')); ?>' id='bt_bb-js'></script>
<script type='text/javascript' src='<?php echo e(url('assets/web/assests/wp-content/plugins/bold-page-builder/script_fe5697.js?ver=5.5.3')); ?>' id='bt_bb_fe-js'></script>
<script type='text/javascript' src='<?php echo e(url('assets/web/assests/wp-content/plugins/bold-timeline/assets/js/bold-timeline5697.js?ver=5.5.3')); ?>' id='bold-timeline-js'></script>
<script type='text/javascript' src='<?php echo e(url('assets/web/assests/wp-content/plugins/bt_cost_calculator/jquery.dd5697.js?ver=5.5.3')); ?>' id='bt_cc_dd-js'></script>
<script type='text/javascript' src='<?php echo e(url('assets/web/assests/wp-content/plugins/bt_cost_calculator/cc.main5697.js?ver=5.5.3')); ?>' id='bt_cc_main-js'></script>



<script type='text/javascript' src='<?php echo e(url('assets/web/assests/wp-content/themes/avantage/framework/js/fancySelect5697.js?ver=5.5.3')); ?>' id='fancySelect-js'></script>

<script type='text/javascript' src='<?php echo e(url('assets/web/assests/wp-content/themes/avantage/framework/js/header.misc5697.js?ver=5.5.3')); ?>' id='avantage-header-js'></script>
<script type='text/javascript' src='<?php echo e(url('assets/web/assests/wp-content/themes/avantage/framework/js/misc5697.js?ver=5.5.3')); ?>' id='avantage-misc-js'></script>
<script type='text/javascript' src='<?php echo e(url('assets/web/assests/wp-content/themes/avantage/framework/js/framework_misc5697.js?ver=5.5.3')); ?>' id='boldthemes-framework-misc-js'></script>

<script type='text/javascript' src='<?php echo e(url('assets/web/assests/wp-includes/js/wp-embed.min5697.js?ver=5.5.3')); ?>' id='wp-embed-js'></script>
<script type='text/javascript' src='<?php echo e(url('assets/web/assests/wp-content/plugins/bold-page-builder/content_elements/bt_bb_section/bt_bb_elements5697.js?ver=5.5.3')); ?>' id='bt_bb_elements-js'></script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\technow\resources\views/Web/include/footer.blade.php ENDPATH**/ ?>