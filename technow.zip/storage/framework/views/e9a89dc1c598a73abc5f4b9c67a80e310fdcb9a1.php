
        <!--**********************************
            Sidebar start
        ***********************************-->
        <div class="nk-sidebar">
            <div class="nk-nav-scroll">
                <ul class="metismenu" id="menu">
                    <li class="nav-label">Dashboard</li>
                    <li>
                        <a class="" href="<?php echo e(url('/admin')); ?>" aria-expanded="false">
                            <i class="icon-speedometer menu-icon"></i><span class="nav-text">Dashboard</span>
                        </a>
                    </li>
                    <li class="nav-label">Pages</li>
                    <li class="mega-menu mega-menu-sm">
                        <a class="" href="<?php echo e(url('/admin/team-list')); ?>" aria-expanded="false">
                            <i class="bxs-user-check menu-icon"></i><span class="nav-text">Team</span>
                        </a>
                    </li>
                    <li class="mega-menu mega-menu-sm">
                        <a class="" href="<?php echo e(url('/admin/services-list')); ?>" aria-expanded="false">
                            <i class="bxs-user-check menu-icon"></i><span class="nav-text">Services</span>
                        </a>
                    </li>
                    <li class="mega-menu mega-menu-sm">
                        <a class="" href="<?php echo e(url('/admin/user-list')); ?>" aria-expanded="false">
                            <i class="bxs-user-check menu-icon"></i><span class="nav-text">Users</span>
                        </a>
                    </li>
                    <li class="mega-menu mega-menu-sm">
                        <a class="" href="<?php echo e(url('/admin/home-content')); ?>" aria-expanded="false">
                            <i class="bxs-user-check menu-icon"></i><span class="nav-text">Home Page Content</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <!--**********************************
            Sidebar end
        ***********************************-->
<?php /**PATH C:\xampp\htdocs\technow\resources\views/Admin/inc/sidebar.blade.php ENDPATH**/ ?>